﻿Imports System
Imports System.Data
Imports System.IO
Imports System.Xml
Imports System.Data.SqlClient
Imports System.Collections.Generic
Imports Microsoft.SqlServer.Management.Smo
Imports Microsoft.SqlServer.Management.Common
Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports System.Text.RegularExpressions
Module BasicFunc

    Public Function ConnectSvr(RefreshOnly As Boolean)
        If MnFrm.svr_Connect.Text = "CONNECT" Or RefreshOnly = True Then
            Dim connection As SqlConnection = New SqlConnection()
            connection.ConnectionString = "Data Source=" & MnFrm.svr_name.Text & ";Initial Catalog=" & MnFrm.svr_dbname.Text & ";Integrated Security=SSPI"
            connection.Open()
            Dim adp As SqlDataAdapter = New SqlDataAdapter(
              "SELECT ('[' + TABLE_CATALOG + '].[' +TABLE_SCHEMA  + '].[' + TABLE_NAME + ']') AS tablename " &
                "From INFORMATION_SCHEMA.TABLES Where TABLE_TYPE ='BASE TABLE' " &
                "AND TABLE_CATALOG = '" & MnFrm.svr_dbname.Text & "'", connection)

            MnFrm.pb_mainProcess.Maximum = 5
            MnFrm.pb_mainProcess.Maximum = 2
            MnFrm.lbl_mainStatsBar.Text = "Processing..."

            Dim ds As DataSet = New DataSet()
            adp.Fill(ds)
            MnFrm.Lst_Tbl_Nm.DataSource = ds.Tables(0)
            MnFrm.Lst_Tbl_Nm.ValueMember = "tablename"
            MnFrm.Lst_Tbl_Nm.DisplayMember = "tablename"

            ServerNm = MnFrm.svr_name.Text
            DBNm = MnFrm.svr_dbname.Text
            MnFrm.svr_dbname.Enabled = False
            MnFrm.svr_name.Enabled = False
            MnFrm.svr_Connect.BackColor = Color.Red
            MnFrm.svr_Connect.Text = "DISCONNECT"
            MnFrm.tx_filter.Enabled = True
            adp.Dispose()
            connection.Close()

            MnFrm.cmbx_tblNm_insrt.DataSource = ds.Tables(0).Copy
            MnFrm.cmbx_tblNm_insrt.ValueMember = "tablename"
            MnFrm.cmbx_tblNm_insrt.DisplayMember = "tablename"

            ServerNm = MnFrm.svr_name.Text
            DBNm = MnFrm.svr_dbname.Text

            'enabling buttons
            MnFrm.But_Export2Exl.Enabled = True
            MnFrm.but_dupTbl.Enabled = True
            MnFrm.but_delTbl.Enabled = True
            MnFrm.But_ImprtXL2Grid.Enabled = True
            MnFrm.but_ExportGrid2Exl.Enabled = True
            MnFrm.But_UpdateRcds.Enabled = True
            MnFrm.but_delete.Enabled = True
            MnFrm.tx_filter.Enabled = True
            MnFrm.ckbx_InsertRcds.Enabled = True
            MnFrm.cmbx_tblNm_insrt.Enabled = True


        Else 'MnFrm.svr_Connect.Text = "DISCONNECT" Then

            MnFrm.svr_dbname.Enabled = True
            MnFrm.svr_name.Enabled = True
            MnFrm.svr_Connect.BackColor = Color.Green
            MnFrm.svr_Connect.Text = "CONNECT"
            MnFrm.tx_filter.Enabled = False
            MnFrm.Lst_Tbl_Nm.DataSource = Nothing
        End If

        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"

        Return True
    End Function

    Public Function GetDBNames()

        Try
            Dim connection As SqlConnection = New SqlConnection()
            connection.ConnectionString = "Data Source=" & MnFrm.svr_name.Text & ";Integrated Security=True"
            connection.Open()

            Dim cmd As SqlCommand = New SqlCommand("sp_databases", connection)
            cmd.CommandType = CommandType.StoredProcedure
            Dim read As SqlDataReader = cmd.ExecuteReader()
            MnFrm.svr_dbname.Items.Clear()
            While read.Read()
                MnFrm.svr_dbname.Items.Add(DirectCast(read("DATABASE_NAME"), String))
            End While
            connection.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return True
    End Function

    Public Function DuplicateTbl(CreateTbl As Boolean) As Integer
        Dim strSQL As String
        Dim rowsAffected As Integer = 0
        Dim FlNm As String
        Dim connectionString As String
        Dim Conn As SqlConnection
        Dim cmd As SqlCommand
        Dim UpdtMsg As String = ""
        Dim TblExists As Integer

        connectionString = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Conn = New SqlConnection(connectionString)
        cmd = New SqlCommand()
        cmd.Connection = Conn
        Conn.Open()
        'Dim transaction As SqlTransaction = Conn.BeginTransaction()
        'cmd.Transaction = transaction
        MnFrm.pb_mainProcess.Maximum = MnFrm.Lst_Tbl_Nm.SelectedItems.Count()
        MnFrm.lbl_mainStatsBar.Text = "Processing..."

        For Each itm In MnFrm.Lst_Tbl_Nm.SelectedItems
            FlNm = itm(0)
            Try
                If CreateTbl = True Then
                    'checking if new table already exists
                    strSQL = "SELECT COUNT(*) AS CNT From INFORMATION_SCHEMA.TABLES Where TABLE_TYPE ='BASE TABLE' " &
                      "AND ('[' + TABLE_CATALOG + '].[' +TABLE_SCHEMA  + '].[' + TABLE_NAME + ']') = '" & Left(FlNm, Len(FlNm) - 1) & "_DP]'"
                    cmd.CommandText = strSQL
                    TblExists = cmd.ExecuteScalar()

                    If TblExists = 1 Then
                        UpdtMsg = UpdtMsg & Left(FlNm, Len(FlNm) - 1) & "_DP] -  already exists "
                        MsgBox(Left(FlNm, Len(FlNm) - 1) & "_DP] -  already exists ")
                    Else
                        strSQL = "Select * INTO " & Left(FlNm, Len(FlNm) - 1) & "_DP] FROM " & FlNm
                        cmd = New SqlCommand(strSQL, Conn)
                        cmd.ExecuteNonQuery()
                        UpdtMsg = UpdtMsg & "  Created " & Left(FlNm, Len(FlNm) - 1) & "_DP] Table "
                    End If

                Else
                    'checking if table exists which needs to be deleted
                    strSQL = "SELECT COUNT(*) AS CNT From INFORMATION_SCHEMA.TABLES Where TABLE_TYPE ='BASE TABLE' " &
                      "AND ('[' + TABLE_CATALOG + '].[' +TABLE_SCHEMA  + '].[' + TABLE_NAME + ']') = '" & FlNm & "'"
                    cmd.CommandText = strSQL
                    TblExists = cmd.ExecuteScalar()

                    If TblExists = 1 Then
                        strSQL = "DROP TABLE " & FlNm
                        If MessageBox.Show("delete table " & FlNm, "Are you sure ?", MessageBoxButtons.YesNo, MessageBoxIcon.Stop) = DialogResult.Yes Then
                            cmd = New SqlCommand(strSQL, Conn)
                            cmd.ExecuteNonQuery()
                            UpdtMsg = UpdtMsg & "Deleted Table " & FlNm
                        End If
                    Else
                        UpdtMsg = UpdtMsg & (FlNm & " Doesnt Exist")
                        MsgBox(FlNm & " Doesnt Exist")
                    End If
                End If

                UpdateLog(True, UpdtMsg)

            Catch ex As Exception
                UpdateLog(True, "Error..." & Err.Description)
            End Try
        Next
        Conn.Close()
        cmd.Dispose()

        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"
        Return 0
    End Function
    'EXPORT TEMPLATE TO EXCEL
    Public Function Export2Exl_NEW() As Integer
        Dim NmbrOfFle As Integer
        Dim FlNm As String
        Dim ShtNm As String
        Dim strSQL As String
        Dim xlFlNm As String = ""
        Dim rs As New ADODB.Recordset
        Dim cnn As ADODB.Connection
        Dim cnnStr As String
        Dim xlApp As New Excel.Application

        If xlApp Is Nothing Then
            UpdateLog(True, "ERROR...Excel not installed/ found")
            End
        End If

        Dim xlWB As Excel.Workbook = xlApp.Workbooks.Add  ' create a new workbook
        Dim xlWS As Excel.Worksheet = xlWB.Worksheets(1)
        Dim xlSh As Excel.Worksheet
        'xlApp.Visible = True

        CheckFolder(ExlExprtPath)

        MnFrm.pb_mainProcess.Maximum = MnFrm.Lst_Tbl_Nm.SelectedItems.Count()
        MnFrm.lbl_mainStatsBar.Text = "Processing..."

        Try
            'If Not cnn.State = ConnectionState.Closed Then
            '    cnn.Open()
            'End If
            'cn.ConnectionString = ("Provider=sqloledb;Data Source=" & getServerName() & ";Initial Catalog=" & getDBName() & ";Integrated Security=SSPI")
            cnnStr = "Provider=sqloledb;Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
            cnn = New ADODB.Connection
            cnn.Open(cnnStr)


            For Each itm In MnFrm.Lst_Tbl_Nm.SelectedItems
                FlNm = itm(0)
                UpdateLog(True, "Reading ... " & FlNm)
                strSQL = "SELECT * FROM " & FlNm & " ;"

                ' Open employee table  
                'rs = New ADODB.Recordset
                rs.Open(strSQL, cnn)

                'rs = cnn.Execute(strSQL)
                xlWS = xlWB.Worksheets.Add(After:=xlWB.Sheets(xlWB.Sheets.Count))
                ShtNm = Regex.Replace(FlNm, "_TEMPLATE", "", RegexOptions.IgnoreCase)
                ShtNm = Right(ShtNm, Len(ShtNm) - InStrRev(ShtNm, "["))
                ShtNm = Regex.Replace(ShtNm, "]", "", RegexOptions.IgnoreCase)
                If Len(ShtNm) > 30 Then ShtNm = Left(ShtNm, 30)
                xlWS.Name = ShtNm
                xlFlNm = xlFlNm & ShtNm & "_"

                With xlWS
                    .Rows("1:1").Interior.ColorIndex = 24
                    For fldcol = 0 To rs.Fields.Count - 1
                        .Cells(1, fldcol + 1).Value = rs.Fields(fldcol).Name
                    Next fldcol
                    .Cells(2, 1).CopyFromRecordset(rs)
                    .Columns.AutoFit()
                End With
                UpdateLog(False, "...DONE")
                MnFrm.pb_mainProcess.Value = NmbrOfFle
                NmbrOfFle = NmbrOfFle + 1
                '  End If
            Next itm

            xlWS = CType(xlApp.Worksheets(1), Excel.Worksheet)
            xlWS.Activate()
            ExlExprtPath = (RootPath & "Excel_Export\")

            If Len(xlFlNm) > 108 Then xlFlNm = Left(xlFlNm, 108)
            xlFlNm = ExlExprtPath & xlFlNm & Format(Now(), "mmddyy_hhmmss") & ".xlsx"
            xlWS.SaveAs(xlFlNm)

            For Each xlSh In xlApp.Sheets
                If xlSh.Name = "Sheet1" Or xlSh.Name = "Sheet2" Or xlSh.Name = "Sheet3" Then
                    xlSh.Delete()
                End If
            Next
            xlApp.Visible = True
            '  xlWB.Close()
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)
            xlApp = Nothing
            xlWB = Nothing
            xlWS = Nothing

            rs.Close()
            rs = Nothing
            cnn.Close()
            cnn = Nothing
            UpdateLog(True, "Exported... " & xlFlNm)



        Catch ex As Exception
            xlWB.Close(False)
            UpdateLog(True, "ERROR..." & Err.Description)
            MsgBox(ex.Message)


        End Try

        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"

        Return NmbrOfFle

    End Function
    ''BACKUP
    Public Function Export2Exl() As Integer
        Dim NmbrOfFle As Integer
        Dim FlNm As String
        Dim ShtNm As String
        Dim strSQL As String
        Dim xlFlNm As String = ""
        Dim cnn As New ADODB.Connection
        Dim rs As New ADODB.Recordset
        Dim xlApp As New Excel.Application

        If xlApp Is Nothing Then
            UpdateLog(True, "ERROR...Excel not installed/ found")
            End
        End If

        Dim xlWB As Excel.Workbook = xlApp.Workbooks.Add  ' create a new workbook
        Dim xlWS As Excel.Worksheet = xlWB.Worksheets(1)
        Dim xlSh As Excel.Worksheet
        'xlApp.Visible = True

        CheckFolder(ExlExprtPath)

        MnFrm.pb_mainProcess.Maximum = MnFrm.Lst_Tbl_Nm.SelectedItems.Count()
        MnFrm.lbl_mainStatsBar.Text = "Processing..."

        Try
            'cn.ConnectionString = ("Provider=sqloledb;Data Source=" & getServerName() & ";Initial Catalog=" & getDBName() & ";Integrated Security=SSPI")
            cnn.ConnectionString = ("Provider=sqloledb;Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI")

            If cnn.State = ConnectionState.Closed Then
                cnn.Open()
            End If

            For Each itm In MnFrm.Lst_Tbl_Nm.SelectedItems
                FlNm = itm(0)
                UpdateLog(True, "Reading ... " & FlNm)
                strSQL = "SELECT * FROM " & FlNm & " ;"
                rs = cnn.Execute(strSQL)
                xlWS = xlWB.Worksheets.Add(After:=xlWB.Sheets(xlWB.Sheets.Count))
                ShtNm = Regex.Replace(FlNm, "_TEMPLATE", "", RegexOptions.IgnoreCase)
                ShtNm = Right(ShtNm, Len(ShtNm) - InStrRev(ShtNm, "["))
                ShtNm = Regex.Replace(ShtNm, "]", "", RegexOptions.IgnoreCase)
                If Len(ShtNm) > 30 Then ShtNm = Left(ShtNm, 30)
                xlWS.Name = ShtNm
                xlFlNm = xlFlNm & ShtNm & "_"

                With xlWS
                    .Rows("1:1").Interior.ColorIndex = 24
                    For fldcol = 0 To rs.Fields.Count - 1
                        .Cells(1, fldcol + 1).Value = rs.Fields(fldcol).Name
                    Next fldcol
                    .Cells(2, 1).CopyFromRecordset(rs)
                    .Columns.AutoFit()
                End With
                UpdateLog(False, "...DONE")
                MnFrm.pb_mainProcess.Value = NmbrOfFle
                NmbrOfFle = NmbrOfFle + 1
                '  End If
            Next itm

            xlWS = CType(xlApp.Worksheets(1), Excel.Worksheet)
            xlWS.Activate()
            ExlExprtPath = (RootPath & "Excel_Export\")

            If Len(xlFlNm) > 108 Then xlFlNm = Left(xlFlNm, 108)
            xlFlNm = ExlExprtPath & xlFlNm & Format(Now(), "mmddyy_hhmmss") & ".xlsx"
            xlWS.SaveAs(xlFlNm)

            For Each xlSh In xlApp.Sheets
                If xlSh.Name = "Sheet1" Or xlSh.Name = "Sheet2" Or xlSh.Name = "Sheet3" Then
                    xlSh.Delete()
                End If
            Next
            xlApp.Visible = True
            '  xlWB.Close()
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)
            xlApp = Nothing
            xlWB = Nothing
            xlWS = Nothing

            rs.Close()
            rs = Nothing
            cnn.Close()
            cnn = Nothing
            UpdateLog(True, "Exported... " & xlFlNm)



        Catch ex As Exception
            xlWB.Close(False)
            UpdateLog(True, "ERROR..." & Err.Description)
            MsgBox(ex.Message)


        End Try

        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"

        Return NmbrOfFle

    End Function
    'DATAGRID ... LOAD VALUES IN GRID FROM TABLE
    Public Function LoadTbl_DataGrid(TblNm As String) As Integer
        Dim watch As New Stopwatch()
        Dim StrSQL As String
        Dim sqlConnectionString As String = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Dim connection As SqlConnection = New SqlConnection(sqlConnectionString)
        Dim cmd As SqlCommand = New SqlCommand()
        cmd.Connection = connection
        connection.Open()
        StrSQL = "SELECT * FROM " & TblNm
        UpdateLog(True, "Running ... " & StrSQL)

        MnFrm.pb_mainProcess.Maximum = 5
        MnFrm.pb_mainProcess.Value = 2
        Try
            cmd.CommandText = StrSQL
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim dt As New DataTable
            dt.Load(reader)
            MnFrm.dgv_MsmtDta.DataSource = dt
            MnFrm.dgv_MsmtDta.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
            reader.Close()
        Catch ex As Exception
            UpdateLog(True, "ERROR... " & Err.Description)
        End Try
        connection.Close()
        cmd.Dispose()

        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"

        Return MnFrm.dgv_MsmtDta.RowCount - 1

    End Function
    'DATAGRID ... LOAD EXTERNAL EXCEL FILE TO GRID
    Public Sub Load_XL2Grid()
        Dim ofd As New OpenFileDialog
        Dim SheetNm As String
        ofd.Filter = "Excel Files|*.xlsx;"
        ofd.Title = "Select Excel File"
        ofd.InitialDirectory = RootPath & "Excel_Export"
        If ofd.ShowDialog <> System.Windows.Forms.DialogResult.OK Then
            UpdateLog(True, "CANCELLED...Cancelled by User")
            Exit Sub
        End If

        Dim connString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & ofd.FileName & ";Extended Properties=Excel 12.0;"


        Try
            Using conn As New OleDbConnection(connString)
                conn.Open()
                Dim dtSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, New Object() {Nothing, Nothing, Nothing, "TABLE"})
                SheetNm = dtSchema.Rows(0).Field(Of String)("TABLE_NAME")
                conn.Close()
                conn.Dispose()
            End Using

            Dim MyConn As OleDbConnection
            MyConn = New OleDbConnection
            MyConn.ConnectionString = connString
            Dim da As OleDbDataAdapter

            MnFrm.pb_mainProcess.Maximum = 5
            MnFrm.pb_mainProcess.Value = 2

            da = New OleDbDataAdapter("SELECT * from [" & SheetNm & "]", MyConn) 'Change items to your database name
            Dim ds As New DataSet
            da.Fill(ds)
            MnFrm.dgv_MsmtDta.DataSource = ds.Tables(0)
            MnFrm.dgv_MsmtDta.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
            UpdateLog(True, "Imported " & ofd.FileName)
        Catch ex As Exception
            UpdateLog(True, "ERROR... " & Err.Description)
        End Try
        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"
    End Sub
    'DATAGRID ------  EXPORT GRID TO EXCEL
    Function Export_Grid_2_Exl()
        If MnFrm.dgv_MsmtDta Is Nothing OrElse MnFrm.dgv_MsmtDta.RowCount <= 0 Then
            UpdateLog(True, "ERROR...No data to Export")
            Return False
            Exit Function
        End If


        Dim misValue As Object = System.Reflection.Missing.Value

        MnFrm.pb_mainProcess.Maximum = 5
        MnFrm.pb_mainProcess.Value = 2

        Try
            Dim xlApp As New Excel.Application
            Dim xlWorkBook As Excel.Workbook
            Dim xlFlNm = ""
            xlWorkBook = xlApp.Workbooks.Add '(misValue)
            xlApp.Visible = True
            Dim xlWorkSheet = xlWorkBook.ActiveSheet

            'Data transfer from grid to Excel. 
            With xlWorkSheet
                'Set Clipboard Copy Mode
                MnFrm.dgv_MsmtDta.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
                MnFrm.dgv_MsmtDta.SelectAll()
                'Get the content from Grid for Clipboard
                Dim str As String = TryCast(MnFrm.dgv_MsmtDta.GetClipboardContent().GetData(DataFormats.UnicodeText), String)
                'Set the content to Clipboard
                Clipboard.SetText(str, TextDataFormat.UnicodeText)
                'Identifiy and select the range of cells in excel to paste the clipboard data.
                .Range("A1:" & ConvertToLetter(MnFrm.dgv_MsmtDta.ColumnCount) & MnFrm.dgv_MsmtDta.RowCount, misValue).Select()
                'Paste the clipboard data
                .Paste()

                MnFrm.dgv_MsmtDta.SelectionMode = False
                'Clipboard.Clear()
                Clipboard.SetText("null", TextDataFormat.UnicodeText)

                .Rows("1:1").Interior.ColorIndex = 24
                .Columns.AutoFit()
                .Columns("A:A").delete()
                .range("A1").select()

                'xlFlNm = ExlExprtPath & MnFrm.cmbx_tblNm_insrt.Text & "_" & Format(Now(), "mmddyy_hhmmss") & ".xlsx"
                xlFlNm = MnFrm.cmbx_tblNm_insrt.Text & "_" & Format(Now(), "mmddyy_hhmmss") & ".xlsx"
                xlFlNm = Right(xlFlNm, Len(xlFlNm) - InStrRev(xlFlNm, "["))
                xlFlNm = Regex.Replace(xlFlNm, "]", "", RegexOptions.IgnoreCase)
                xlFlNm = ExlExprtPath & xlFlNm
                .SaveAs(xlFlNm)
                UpdateLog(True, "EXPORTED..." & xlFlNm)
            End With
            ' releaseObject(xlWorkBook)
            releaseObject(xlWorkSheet)
            releaseObject(xlApp)

        Catch ex As Exception
            UpdateLog(True, "ERROR..." & Err.Description)
        End Try
        MnFrm.pb_mainProcess.Value = 5
        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"

    End Function
    'DATAGRID ------ update values
    'Public Function Update_DtaVw_Rcds(DeleteOnly As Boolean) As Integer
    Public Function Update_DtaVw_Rcds(DeleteOnly As Boolean) As Integer
        Dim connetionString As String
        Dim ColNm
        Dim ColVal
        Dim ColValFnl
        Dim strSQL As String
        Dim i As Integer
        Dim ColFilled As Boolean
        Dim rowsAffected As Integer = 0
        Dim rowsAffected2 As Integer = 0

        connetionString = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Dim connectionString As String = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Dim connection As SqlConnection = New SqlConnection(connectionString)
        Dim cmd As SqlCommand = New SqlCommand()
        cmd.Connection = connection
        connection.Open()

        MnFrm.pb_mainProcess.Maximum = 5
        MnFrm.pb_mainProcess.Value = 2
        ' Execute as a transaction, roll back if it fails
        Dim transaction As SqlTransaction = connection.BeginTransaction()
        cmd.Transaction = transaction
        Try
            If MnFrm.ckbx_InsertRcds.Checked = False Or DeleteOnly = True Then
                'BEFORE UPDATING RECORDS WE ARE DELETING EXISING RECORDS
                strSQL = "DELETE " & MnFrm.cmbx_tblNm_insrt.Text
                UpdateLog(True, "RUNNING..." & LCase(strSQL))
                cmd.CommandText = strSQL
                rowsAffected = cmd.ExecuteNonQuery()
                If DeleteOnly = True Then GoTo CommitTran : 
            End If

            'ADDING RECORDS FROM DATAGRIDVIEW
            ColFilled = False
            ColNm = ""
            ColValFnl = ""
            For Each row As DataGridViewRow In MnFrm.dgv_MsmtDta.Rows
                i = 0
                If MnFrm.dgv_MsmtDta.RowCount = 1 Then GoTo CommitTran
                If Not row.IsNewRow Then
                    ColVal = ""
                    For Each col As DataGridViewColumn In MnFrm.dgv_MsmtDta.Columns
                        If ColFilled = False Then ColNm = ColNm & "[" & col.Name & "], "
                        'ColVal = ColVal & "'" & IIf(IsDBNull(row.Cells(i).Value) = True, "NULL", row.Cells(i).Value.ToString) & "', "
                        ColVal = ColVal & "'" & Replace(Replace(row.Cells(i).Value.ToString, "''", "'"), "'", "''") & "', "  ' removing '' and adding '
                        i = i + 1
                    Next
                    ColFilled = True
                    ColVal = Left(ColVal, Len(ColVal) - 2)   ' removing comma and space
                    ColValFnl = ColValFnl & " SELECT " & ColVal & vbNewLine & " UNION ALL "
                End If
            Next
            ColValFnl = Left(ColValFnl, Len(ColValFnl) - 11)
            'ColValFnl = Replace(ColValFnl, "'NULL'", "NULL") 'changing 'null' values to NULL
            ColNm = Left(ColNm, Len(ColNm) - 2)
            ' strSQL = "INSERT INTO " & DBNm & ".dbo." & MnFrm.cmbx_tblNm_insrt.Text & " (" & ColNm & ") " & ColValFnl
            strSQL = "INSERT INTO " & MnFrm.cmbx_tblNm_insrt.Text & " (" & ColNm & ") " & ColValFnl
            UpdateLog(True, "RUNNING..." & LCase(strSQL))
            cmd.CommandText = strSQL
            rowsAffected2 = cmd.ExecuteNonQuery()

        Catch ex As Exception
            UpdateLog(False, "ERROR..." & Err.Description & "..ROLLED BACK")
            transaction.Rollback()
            connection.Close()
            Return 0
            Exit Function
        End Try
CommitTran:
        UpdateLog(True, "Deleted " & rowsAffected & " record(s)")
        UpdateLog(False, " /Added " & rowsAffected2 & " records(s)")
        transaction.Commit()
        connection.Close()
        cmd.Dispose()

        BasicFunc.LoadTbl_DataGrid(MnFrm.cmbx_tblNm_insrt.Text)
        Refresh_Grid()
        MnFrm.pb_mainProcess.Value = MnFrm.pb_mainProcess.Maximum
        MnFrm.lbl_mainStatsBar.Text = "Ready"
        Return 1
    End Function

    Public Sub UpdateProgressBar(ByVal Val, ByVal MaxVal)
        If MaxVal <> False Then MnFrm.pb_mainProcess.Maximum = MaxVal
        If Val <> False And Val <= MnFrm.pb_mainProcess.Maximum Then MnFrm.pb_mainProcess.Value = Val
        ' MnFrm.pb_mainProcess.Refresh()
        'Application.DoEvents()
    End Sub
    Public Sub UpdateLog(ByVal NewLine As Boolean, ByVal LogMsg As String)
        If LogMsg = "START>>" Then
            MnFrm.Txt_Log.AppendText(vbNewLine)
            MnFrm.Txt_Log.AppendText("----------------------------------------------------------------------------------------------------------------------------------")
            MnFrm.Txt_Log.AppendText(vbNewLine & "START>>" & " " & Format(Now(), "hh:mm:ss tt"))
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(182, 182, 0)
            MnFrm.lbl_mainStatsBar.Text = "Processing..."
        ElseIf LogMsg = "<<END" Then
            MnFrm.Txt_Log.AppendText(vbNewLine & "<<END" & " " & Format(Now(), "hh:mm:ss tt"))
            MnFrm.lbl_mainStatsBar.Text = "Ready"
        Else
            If NewLine = True Then
                MnFrm.Txt_Log.AppendText(vbNewLine & LogMsg)
            Else
                MnFrm.Txt_Log.AppendText(LogMsg)
            End If
            If InStr(LogMsg, "DONE") = 0 Then MnFrm.lbl_mainStatsBar.Text = LogMsg
        End If
        MnFrm.lbl_mainStatsBar.Refresh()

        MnFrm.Txt_Log.SelectionStart = MnFrm.Txt_Log.Text.Length
        MnFrm.Txt_Log.Refresh()
        MnFrm.Txt_Log.ScrollToCaret()

        Dim LastScript() As String = Split(MnFrm.Txt_Log.Text, "START>>")
        If InStr((LastScript(UBound(LastScript))), "ERROR...") > 0 Then
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(196, 0, 0)
        ElseIf InStr((LastScript(UBound(LastScript))), "CANCELLED by User") > 0 Then
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(196, 0, 0)
        ElseIf LogMsg = "<<END" And MnFrm.Txt_Log.ForeColor <> Color.FromArgb(196, 0, 0) Then
            MnFrm.Txt_Log.ForeColor = Color.FromArgb(1, 222, 0)
        End If


    End Sub
    Public Function SelectionCheck(ByVal OnlyTemplateScripts As Boolean) As Boolean
        Dim IsSelected As Boolean
        For Each Itm In MnFrm.Lst_Tbl_Nm.SelectedItems
            IsSelected = True
        Next
        If IsSelected = False Then
            MsgBox("Select atleast one table from the list", MsgBoxStyle.Critical, Title:="Selection Required")
            Return False
        Else
            Return True
        End If
    End Function
    Private Function ConvertToLetter(ByVal num As Integer) As String
        'Method to convert an column number to column name
        If num < 0 Or num >= 27 * 26 Then
            ConvertToLetter = "-"
        Else
            If num < 26 Then
                ConvertToLetter = Chr(num + 65)
            Else
                ConvertToLetter = Chr(num \ 26 + 64) + Chr(num Mod 26 + 65)
            End If
        End If
    End Function
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub
    Public Sub Refresh_Grid()
        MnFrm.dgv_statusbar.Text = IIf(MnFrm.dgv_MsmtDta.RowCount = 0, 0, MnFrm.dgv_MsmtDta.RowCount - 1) & " row(s)"
    End Sub

    Public Function CheckFolder(ByVal FolderPath As String)
        If (Not System.IO.Directory.Exists(FolderPath)) Then
            System.IO.Directory.CreateDirectory(FolderPath)
        End If
        Return True
    End Function

    Public Function getServerName() As String
        Return MnFrm.svr_name.Text
    End Function

    Public Function getDBName() As String
        Return MnFrm.svr_dbname.Text
    End Function



End Module