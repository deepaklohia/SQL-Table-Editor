﻿Imports System.Data.SqlClient
Imports Microsoft.WindowsAPICodePack.Taskbar
Imports System.IO
Imports System.Text.RegularExpressions
Public Module GlobalVariables
    Public RootPath As String
    Public CustPath As String
    Public XMLPath As String
    Public ErrChkScrptPath As String
    Public ExlExprtPath As String
    Public DeleteRcdsSQLQry As String
    Public CustPathCustName As String
    '**************************CHANGE  ME START*******************************************
    Public ServerNm As String = "localhost"
    '**************************CHANGE  END************************************************
    Public DBNm As String
    Public TotalScrpts As Integer
    Public UpdtLogFlg As Boolean
    Public UpDtLogMsg1 As Boolean
    Public UpDtLogMsg2 As String
    Public Length As Integer
    Public StrSQL As String
    '**************************************************************************************
    Public ImgPath As String
    'Public Event DataError As System.Windows.Forms.DataGridViewDataErrorEventHandler
    '**************************************************************************************
End Module
Public Class MnFrm
    Private Sub UserForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'Dim path As String = AppDomain.CurrentDomain.BaseDirectory
        Dim prjPath As String = Directory.GetCurrentDirectory
        ImgPath = prjPath.Replace("\bin\Debug", "\images")

        '**********************************************************************************
        RootPath = "C:\Users\" & Environ("UserName") & "\Desktop\"
        '**********************************************************************************
        CheckFolder(RootPath)
        ExlExprtPath = (RootPath & "Excel_Export\")
        CheckFolder(ExlExprtPath)

        tx_filter.Enabled = False
        Me.svr_name.Text = ServerNm

        If Me.svr_name.Text <> "" Then GetDBNames()
        MaximizeBox = False
        '  Me.but_ColExpndArrow.Text = "<<"
        '  but_ColExpndArrow_Click(sender, New System.EventArgs())

        Dim toolTip1 As New ToolTip()
        toolTip1.AutoPopDelay = 5000
        toolTip1.InitialDelay = 1000
        toolTip1.ReshowDelay = 500
        Me.cmbx_tblNm_insrt.Enabled = False
        Me.Width = 1185
    End Sub

    Private Sub svr_Connect_Click(sender As Object, e As EventArgs) Handles svr_Connect.Click
        If Me.svr_dbname.Text = "" Then
            MsgBox("Please enter DB Name  ", vbCritical, Title:="DB Name Missing")
            Exit Sub
        ElseIf Me.svr_name.Text = "" Then
            MsgBox("Please enter Server Name", vbCritical, Title:="Server Name Missing")
            Exit Sub
        End If

        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        BasicFunc.ConnectSvr(False)
        UpdateLog(True, "<<END")
    End Sub
    Private Sub tx_filter_TextChanged(sender As Object, e As EventArgs) Handles tx_filter.TextChanged
        'If SelectionCheck(False) = False Then Exit Sub
        If Lst_Tbl_Nm.SelectedIndex = -1 Then Return
        Dim tbl As DataTable = TryCast(Me.Lst_Tbl_Nm.DataSource, DataTable)
        tbl.DefaultView.RowFilter = "[tablename] Like '%" & tx_filter.Text & "%'"
    End Sub
    Private Sub Bt_CopyLog_Click(sender As System.Object, e As System.EventArgs) Handles Bt_CopyLog.Click
        If Control.ModifierKeys = Keys.Alt Then
            Try
                Dim flePath As String = XMLPath & "\Log_" & Format(Now(), "mmddyy_hhmmss") & ".txt"
                Dim NewFle = System.IO.File.CreateText(flePath)
                NewFle.WriteLine(Me.Txt_Log.Text)
                NewFle.Close()
                Process.Start("notepad.exe", flePath)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If
        Me.pb_mainProcess.Value = 0
        If Me.Txt_Log.Text <> "" Then Clipboard.SetText(Me.Txt_Log.Text)
    End Sub
    Private Sub But_Export2Exl_Click(sender As System.Object, e As System.EventArgs) Handles But_Export2Exl.Click

        If Control.ModifierKeys = Keys.Alt Then
            Try
                Process.Start(ExlExprtPath)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If

        If SelectionCheck(False) = False Then Exit Sub
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        BasicFunc.Export2Exl()
        UpdateLog(True, "<<END")
    End Sub
    Private Sub but_ExportGrid2Exl_Click(sender As System.Object, e As System.EventArgs) Handles but_ExportGrid2Exl.Click
        If Control.ModifierKeys = Keys.Alt Then
            Try
                Process.Start(ExlExprtPath)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        BasicFunc.Export_Grid_2_Exl()
        UpdateLog(True, "<<END")
    End Sub

    Public Sub dgv_MsmtDta_SelectionChanged(sender As Object, e As System.EventArgs) Handles dgv_MsmtDta.SelectionChanged
        Call Refresh_Grid()
    End Sub

    Private Sub ckbx_InsertRcds_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles ckbx_InsertRcds.CheckedChanged
        If Me.ckbx_InsertRcds.Checked = True Then
            Me.But_UpdateRcds.Text = "INSERT"
            Me.cmbx_tblNm_insrt.Enabled = True
            '  Me.cmbx_tblNm_insrt.DropDownStyle = ComboBoxStyle.DropDown
        Else
            Me.But_UpdateRcds.Text = "UPDATE"
            Me.cmbx_tblNm_insrt.Enabled = False
            '   Me.cmbx_tblNm_insrt.DropDownStyle = ComboBoxStyle.DropDownList
        End If
    End Sub

    Private Sub but_ColExpndArrow_Click(sender As System.Object, e As System.EventArgs) Handles but_ColExpndArrow.Click
        If Me.but_ColExpndArrow.Text = "<<" Then
            Me.Width = 475
            Me.but_ColExpndArrow.Text = ">>"
        Else
            Me.Width = 1185
            Me.but_ColExpndArrow.Text = "<<"
        End If
        Me.CenterToScreen()
    End Sub

    Private Sub but_delete_Click(sender As Object, e As EventArgs) Handles but_delete.Click
        If Me.cmbx_tblNm_insrt.Text = "" Then
            UpdateLog(True, "ERROR...no source table / error script found.")
            Exit Sub
        Else
            If MessageBox.Show("You are about to delete all records from table " & vbNewLine & Me.cmbx_tblNm_insrt.Text, "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
                UpdateLog(True, "START>>")
                Me.pb_mainProcess.Value = 0
                BasicFunc.Update_DtaVw_Rcds(True)
                'BasicFunc.Refresh_Grid()
                UpdateLog(True, "<<END")
            Else
                UpdateLog(True, "ERROR...user cancelled.")
            End If
        End If
    End Sub

    Private Sub but_dupTbl_Click(sender As Object, e As EventArgs) Handles but_dupTbl.Click
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        BasicFunc.DuplicateTbl(True)
        BasicFunc.ConnectSvr(True)
        UpdateLog(True, "<<END")
    End Sub

    Private Sub but_delTbl_Click(sender As Object, e As EventArgs) Handles but_delTbl.Click
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        BasicFunc.DuplicateTbl(False)
        BasicFunc.ConnectSvr(True)
        UpdateLog(True, "<<END")
    End Sub

    Private Sub But_UpdateRcds_Click(sender As Object, e As EventArgs) Handles But_UpdateRcds.Click
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0

        If Me.cmbx_tblNm_insrt.Text = "" Then
            UpdateLog(True, "ERROR...no source table / error script found.")
        Else
            UpdateLog(True, "START>>")
            Me.pb_mainProcess.Value = 0
            BasicFunc.Update_DtaVw_Rcds(False)
            UpdateLog(True, "<<END")
        End If
    End Sub
    Private Sub But_ImprtXL2Grid_Click(sender As Object, e As EventArgs) Handles But_ImprtXL2Grid.Click

        If Control.ModifierKeys = Keys.Alt Then
            Process.Start(ExlExprtPath)
            Exit Sub
        End If

        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        BasicFunc.Load_XL2Grid()
        BasicFunc.Refresh_Grid()
        UpdateLog(True, "<<END")
    End Sub

    Private Sub Lst_Tbl_Nm_Click(sender As Object, e As EventArgs) Handles Lst_Tbl_Nm.Click
        Me.but_ColExpndArrow.Text = ">>"
        Me.cmbx_tblNm_insrt.Text = Me.Lst_Tbl_Nm.Text

        Dim itm
        For Each itm In Me.Lst_Tbl_Nm.SelectedItems
            BasicFunc.LoadTbl_DataGrid(itm(0))
            BasicFunc.Refresh_Grid()
            Exit For
        Next itm

        Me.cmbx_tblNm_insrt.Enabled = False
    End Sub

    Private Sub dgv_MsmtDta_DataError(sender As Object, e As DataGridViewDataErrorEventArgs) Handles dgv_MsmtDta.DataError

        'MsgBox(e.Context.ToString(), vbOKOnly, "Invalid Value")
        MsgBox("Invalid Value Entered", vbOKOnly + vbCritical, "Invalid Value")
        dgv_MsmtDta.Rows(e.RowIndex).ErrorText = "Error"
        dgv_MsmtDta.Rows(e.RowIndex).Cells(e.ColumnIndex).ErrorText = "Invalid value"

        'If (e.Context = DataGridViewDataErrorContexts.Commit) Then MsgBox("Commit error")
        'If (e.Context = DataGridViewDataErrorContexts.CurrentCellChange) Then MsgBox("Cell change")
        'If (e.Context = DataGridViewDataErrorContexts.Parsing) Then MsgBox("parsing error")
        'If (e.Context = DataGridViewDataErrorContexts.LeaveControl) Then MsgBox("leave control error")

        'If TypeOf (e.Exception) Is ConstraintException Then
        '    Dim view As DataGridView = CType(sender, DataGridView)
        '    view.Rows(e.RowIndex).ErrorText = "an error"
        '    view.Rows(e.RowIndex).Cells(e.ColumnIndex).ErrorText = "an error"
        'End If
        e.ThrowException = False
    End Sub

    Private Sub dgv_MsmtDta_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles dgv_MsmtDta.CellValidating
        dgv_MsmtDta.Rows(e.RowIndex).ErrorText = ""
        dgv_MsmtDta.Rows(e.RowIndex).Cells(e.ColumnIndex).ErrorText = ""
        ''e.Cancel = True
        'Try
        '    dgv_MsmtDta.Rows(e.RowIndex).Cells(e.ColumnIndex).ErrorText = "TUMBA"
        'Catch ex As Exception
        '    'Me.dgv_MsmtDta.Rows(e.RowIndex).ErrorText = "An item with this name already exists"
        '    'dgv_MsmtDta.Rows(e.RowIndex).ErrorText = "eRROR"
        '    e.Cancel = True
        'End Try
    End Sub

    Private Sub svr_name_Leave(sender As Object, e As EventArgs) Handles svr_name.Leave
        If Me.svr_name.Text <> "" Then GetDBNames()
    End Sub
End Class

