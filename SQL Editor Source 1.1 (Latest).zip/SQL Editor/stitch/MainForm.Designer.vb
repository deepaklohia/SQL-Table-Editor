﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MnFrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Lst_Tbl_Nm = New System.Windows.Forms.ListBox()
        Me.Bt_CopyLog = New System.Windows.Forms.Button()
        Me.But_Export2Exl = New System.Windows.Forms.Button()
        Me.dgv_MsmtDta = New System.Windows.Forms.DataGridView()
        Me.But_UpdateRcds = New System.Windows.Forms.Button()
        Me.but_ExportGrid2Exl = New System.Windows.Forms.Button()
        Me.But_ImprtXL2Grid = New System.Windows.Forms.Button()
        Me.but_ColExpndArrow = New System.Windows.Forms.Button()
        Me.dgv_statusbar = New System.Windows.Forms.Label()
        Me.cmbx_tblNm_insrt = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl_mainStatsBar = New System.Windows.Forms.Label()
        Me.bgwLongTask = New System.ComponentModel.BackgroundWorker()
        Me.Txt_Log = New System.Windows.Forms.RichTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tx_filter = New System.Windows.Forms.TextBox()
        Me.svr_name = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.svr_Connect = New System.Windows.Forms.Button()
        Me.pb_mainProcess = New System.Windows.Forms.ProgressBar()
        Me.svr_dbname = New System.Windows.Forms.ComboBox()
        Me.but_delTbl = New System.Windows.Forms.Button()
        Me.but_delete = New System.Windows.Forms.Button()
        Me.but_dupTbl = New System.Windows.Forms.Button()
        Me.ckbx_InsertRcds = New System.Windows.Forms.CheckBox()
        CType(Me.dgv_MsmtDta, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Lst_Tbl_Nm
        '
        Me.Lst_Tbl_Nm.FormattingEnabled = True
        Me.Lst_Tbl_Nm.Location = New System.Drawing.Point(12, 57)
        Me.Lst_Tbl_Nm.Name = "Lst_Tbl_Nm"
        Me.Lst_Tbl_Nm.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.Lst_Tbl_Nm.Size = New System.Drawing.Size(341, 420)
        Me.Lst_Tbl_Nm.TabIndex = 1
        '
        'Bt_CopyLog
        '
        Me.Bt_CopyLog.AutoSize = True
        Me.Bt_CopyLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Bt_CopyLog.ForeColor = System.Drawing.Color.White
        Me.Bt_CopyLog.Location = New System.Drawing.Point(359, 404)
        Me.Bt_CopyLog.Name = "Bt_CopyLog"
        Me.Bt_CopyLog.Size = New System.Drawing.Size(105, 24)
        Me.Bt_CopyLog.TabIndex = 8
        Me.Bt_CopyLog.Text = "Copy Log"
        Me.Bt_CopyLog.UseVisualStyleBackColor = False
        '
        'But_Export2Exl
        '
        Me.But_Export2Exl.AutoSize = True
        Me.But_Export2Exl.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.But_Export2Exl.Enabled = False
        Me.But_Export2Exl.ForeColor = System.Drawing.Color.White
        Me.But_Export2Exl.Location = New System.Drawing.Point(359, 79)
        Me.But_Export2Exl.Name = "But_Export2Exl"
        Me.But_Export2Exl.Size = New System.Drawing.Size(105, 24)
        Me.But_Export2Exl.TabIndex = 10
        Me.But_Export2Exl.Text = "Export to Excel"
        Me.But_Export2Exl.UseVisualStyleBackColor = False
        '
        'dgv_MsmtDta
        '
        Me.dgv_MsmtDta.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgv_MsmtDta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgv_MsmtDta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_MsmtDta.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.dgv_MsmtDta.Location = New System.Drawing.Point(470, 31)
        Me.dgv_MsmtDta.Name = "dgv_MsmtDta"
        Me.dgv_MsmtDta.Size = New System.Drawing.Size(697, 461)
        Me.dgv_MsmtDta.TabIndex = 12
        '
        'But_UpdateRcds
        '
        Me.But_UpdateRcds.AutoSize = True
        Me.But_UpdateRcds.BackColor = System.Drawing.Color.Teal
        Me.But_UpdateRcds.Enabled = False
        Me.But_UpdateRcds.ForeColor = System.Drawing.Color.White
        Me.But_UpdateRcds.Location = New System.Drawing.Point(1017, 496)
        Me.But_UpdateRcds.Name = "But_UpdateRcds"
        Me.But_UpdateRcds.Size = New System.Drawing.Size(60, 24)
        Me.But_UpdateRcds.TabIndex = 21
        Me.But_UpdateRcds.Text = "Update"
        Me.But_UpdateRcds.UseVisualStyleBackColor = False
        '
        'but_ExportGrid2Exl
        '
        Me.but_ExportGrid2Exl.AutoSize = True
        Me.but_ExportGrid2Exl.BackColor = System.Drawing.Color.Teal
        Me.but_ExportGrid2Exl.Enabled = False
        Me.but_ExportGrid2Exl.ForeColor = System.Drawing.Color.White
        Me.but_ExportGrid2Exl.Location = New System.Drawing.Point(533, 496)
        Me.but_ExportGrid2Exl.Name = "but_ExportGrid2Exl"
        Me.but_ExportGrid2Exl.Size = New System.Drawing.Size(75, 24)
        Me.but_ExportGrid2Exl.TabIndex = 24
        Me.but_ExportGrid2Exl.Text = "Export to XL"
        Me.but_ExportGrid2Exl.UseVisualStyleBackColor = False
        '
        'But_ImprtXL2Grid
        '
        Me.But_ImprtXL2Grid.AutoSize = True
        Me.But_ImprtXL2Grid.BackColor = System.Drawing.Color.Teal
        Me.But_ImprtXL2Grid.Enabled = False
        Me.But_ImprtXL2Grid.ForeColor = System.Drawing.Color.White
        Me.But_ImprtXL2Grid.Location = New System.Drawing.Point(470, 495)
        Me.But_ImprtXL2Grid.Name = "But_ImprtXL2Grid"
        Me.But_ImprtXL2Grid.Size = New System.Drawing.Size(57, 24)
        Me.But_ImprtXL2Grid.TabIndex = 25
        Me.But_ImprtXL2Grid.Text = "Load XL"
        Me.But_ImprtXL2Grid.UseVisualStyleBackColor = False
        '
        'but_ColExpndArrow
        '
        Me.but_ColExpndArrow.AutoSize = True
        Me.but_ColExpndArrow.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.but_ColExpndArrow.Location = New System.Drawing.Point(430, 245)
        Me.but_ColExpndArrow.Name = "but_ColExpndArrow"
        Me.but_ColExpndArrow.Size = New System.Drawing.Size(34, 30)
        Me.but_ColExpndArrow.TabIndex = 26
        Me.but_ColExpndArrow.Text = ">>"
        Me.but_ColExpndArrow.UseVisualStyleBackColor = True
        Me.but_ColExpndArrow.Visible = False
        '
        'dgv_statusbar
        '
        Me.dgv_statusbar.BackColor = System.Drawing.Color.Transparent
        Me.dgv_statusbar.Location = New System.Drawing.Point(614, 500)
        Me.dgv_statusbar.Name = "dgv_statusbar"
        Me.dgv_statusbar.Size = New System.Drawing.Size(75, 14)
        Me.dgv_statusbar.TabIndex = 29
        Me.dgv_statusbar.Text = "0"
        Me.dgv_statusbar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbx_tblNm_insrt
        '
        Me.cmbx_tblNm_insrt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbx_tblNm_insrt.Enabled = False
        Me.cmbx_tblNm_insrt.FormattingEnabled = True
        Me.cmbx_tblNm_insrt.Location = New System.Drawing.Point(662, 498)
        Me.cmbx_tblNm_insrt.Name = "cmbx_tblNm_insrt"
        Me.cmbx_tblNm_insrt.Size = New System.Drawing.Size(276, 21)
        Me.cmbx_tblNm_insrt.TabIndex = 34
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(12, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 18)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "SERVER NAME"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_mainStatsBar
        '
        Me.lbl_mainStatsBar.BackColor = System.Drawing.Color.Transparent
        Me.lbl_mainStatsBar.Location = New System.Drawing.Point(355, 467)
        Me.lbl_mainStatsBar.Name = "lbl_mainStatsBar"
        Me.lbl_mainStatsBar.Size = New System.Drawing.Size(92, 23)
        Me.lbl_mainStatsBar.TabIndex = 47
        Me.lbl_mainStatsBar.Text = "Status Bar"
        Me.lbl_mainStatsBar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'bgwLongTask
        '
        Me.bgwLongTask.WorkerReportsProgress = True
        Me.bgwLongTask.WorkerSupportsCancellation = True
        '
        'Txt_Log
        '
        Me.Txt_Log.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Log.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_Log.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.Txt_Log.Location = New System.Drawing.Point(359, 368)
        Me.Txt_Log.Name = "Txt_Log"
        Me.Txt_Log.Size = New System.Drawing.Size(105, 30)
        Me.Txt_Log.TabIndex = 48
        Me.Txt_Log.Text = ""
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Teal
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(471, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(696, 18)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "INSERT/UPDATE RECORDS"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(12, 497)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(130, 17)
        Me.Label3.TabIndex = 49
        Me.Label3.Text = "FILTER"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tx_filter
        '
        Me.tx_filter.Location = New System.Drawing.Point(148, 494)
        Me.tx_filter.Name = "tx_filter"
        Me.tx_filter.Size = New System.Drawing.Size(201, 20)
        Me.tx_filter.TabIndex = 50
        '
        'svr_name
        '
        Me.svr_name.Location = New System.Drawing.Point(12, 31)
        Me.svr_name.Name = "svr_name"
        Me.svr_name.Size = New System.Drawing.Size(196, 20)
        Me.svr_name.TabIndex = 51
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(215, 8)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(138, 18)
        Me.Label5.TabIndex = 53
        Me.Label5.Text = "DB NAME"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'svr_Connect
        '
        Me.svr_Connect.AutoSize = True
        Me.svr_Connect.BackColor = System.Drawing.Color.Green
        Me.svr_Connect.ForeColor = System.Drawing.Color.White
        Me.svr_Connect.Location = New System.Drawing.Point(359, 31)
        Me.svr_Connect.Name = "svr_Connect"
        Me.svr_Connect.Size = New System.Drawing.Size(105, 24)
        Me.svr_Connect.TabIndex = 41
        Me.svr_Connect.Text = "CONNECT"
        Me.svr_Connect.UseVisualStyleBackColor = False
        '
        'pb_mainProcess
        '
        Me.pb_mainProcess.Location = New System.Drawing.Point(355, 495)
        Me.pb_mainProcess.Name = "pb_mainProcess"
        Me.pb_mainProcess.Size = New System.Drawing.Size(109, 20)
        Me.pb_mainProcess.TabIndex = 53
        '
        'svr_dbname
        '
        Me.svr_dbname.FormattingEnabled = True
        Me.svr_dbname.Location = New System.Drawing.Point(215, 31)
        Me.svr_dbname.Name = "svr_dbname"
        Me.svr_dbname.Size = New System.Drawing.Size(138, 21)
        Me.svr_dbname.TabIndex = 54
        '
        'but_delTbl
        '
        Me.but_delTbl.AutoSize = True
        Me.but_delTbl.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.but_delTbl.Enabled = False
        Me.but_delTbl.ForeColor = System.Drawing.Color.White
        Me.but_delTbl.Location = New System.Drawing.Point(359, 138)
        Me.but_delTbl.Name = "but_delTbl"
        Me.but_delTbl.Size = New System.Drawing.Size(105, 23)
        Me.but_delTbl.TabIndex = 56
        Me.but_delTbl.Text = "Delete Table"
        Me.but_delTbl.UseVisualStyleBackColor = False
        '
        'but_delete
        '
        Me.but_delete.AutoSize = True
        Me.but_delete.BackColor = System.Drawing.Color.Crimson
        Me.but_delete.Enabled = False
        Me.but_delete.ForeColor = System.Drawing.Color.White
        Me.but_delete.Location = New System.Drawing.Point(1083, 496)
        Me.but_delete.Name = "but_delete"
        Me.but_delete.Size = New System.Drawing.Size(62, 24)
        Me.but_delete.TabIndex = 58
        Me.but_delete.Text = "Delete All"
        Me.but_delete.UseVisualStyleBackColor = False
        '
        'but_dupTbl
        '
        Me.but_dupTbl.AutoSize = True
        Me.but_dupTbl.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.but_dupTbl.Enabled = False
        Me.but_dupTbl.ForeColor = System.Drawing.Color.White
        Me.but_dupTbl.Location = New System.Drawing.Point(359, 108)
        Me.but_dupTbl.Name = "but_dupTbl"
        Me.but_dupTbl.Size = New System.Drawing.Size(105, 24)
        Me.but_dupTbl.TabIndex = 59
        Me.but_dupTbl.Text = "Duplicate Table"
        Me.but_dupTbl.UseVisualStyleBackColor = False
        '
        'ckbx_InsertRcds
        '
        Me.ckbx_InsertRcds.AutoSize = True
        Me.ckbx_InsertRcds.Enabled = False
        Me.ckbx_InsertRcds.Location = New System.Drawing.Point(945, 500)
        Me.ckbx_InsertRcds.Name = "ckbx_InsertRcds"
        Me.ckbx_InsertRcds.Size = New System.Drawing.Size(66, 17)
        Me.ckbx_InsertRcds.TabIndex = 60
        Me.ckbx_InsertRcds.Text = "INSERT"
        Me.ckbx_InsertRcds.UseVisualStyleBackColor = True
        '
        'MnFrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1177, 521)
        Me.Controls.Add(Me.ckbx_InsertRcds)
        Me.Controls.Add(Me.but_dupTbl)
        Me.Controls.Add(Me.but_delete)
        Me.Controls.Add(Me.but_delTbl)
        Me.Controls.Add(Me.svr_dbname)
        Me.Controls.Add(Me.svr_Connect)
        Me.Controls.Add(Me.But_Export2Exl)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pb_mainProcess)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tx_filter)
        Me.Controls.Add(Me.svr_name)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.dgv_MsmtDta)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbx_tblNm_insrt)
        Me.Controls.Add(Me.dgv_statusbar)
        Me.Controls.Add(Me.but_ColExpndArrow)
        Me.Controls.Add(Me.But_ImprtXL2Grid)
        Me.Controls.Add(Me.but_ExportGrid2Exl)
        Me.Controls.Add(Me.But_UpdateRcds)
        Me.Controls.Add(Me.Bt_CopyLog)
        Me.Controls.Add(Me.Lst_Tbl_Nm)
        Me.Controls.Add(Me.Txt_Log)
        Me.Controls.Add(Me.lbl_mainStatsBar)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "MnFrm"
        Me.Text = "SQL Editor"
        CType(Me.dgv_MsmtDta, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Lst_Tbl_Nm As System.Windows.Forms.ListBox
    Friend WithEvents Bt_CopyLog As System.Windows.Forms.Button
    Friend WithEvents But_Export2Exl As System.Windows.Forms.Button
    Friend WithEvents dgv_MsmtDta As System.Windows.Forms.DataGridView
    Friend WithEvents But_UpdateRcds As System.Windows.Forms.Button
    Friend WithEvents but_ExportGrid2Exl As System.Windows.Forms.Button
    Friend WithEvents But_ImprtXL2Grid As System.Windows.Forms.Button
    Friend WithEvents but_ColExpndArrow As System.Windows.Forms.Button
    Friend WithEvents dgv_statusbar As System.Windows.Forms.Label
    Friend WithEvents cmbx_tblNm_insrt As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbl_mainStatsBar As System.Windows.Forms.Label
    Private WithEvents bgwLongTask As System.ComponentModel.BackgroundWorker
    Friend WithEvents Txt_Log As System.Windows.Forms.RichTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents tx_filter As TextBox
    Friend WithEvents svr_name As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents svr_Connect As Button
    Friend WithEvents pb_mainProcess As ProgressBar
    Friend WithEvents svr_dbname As ComboBox
    Friend WithEvents but_delTbl As Button
    Friend WithEvents but_delete As Button
    Friend WithEvents but_dupTbl As Button
    Friend WithEvents ckbx_InsertRcds As CheckBox
End Class
