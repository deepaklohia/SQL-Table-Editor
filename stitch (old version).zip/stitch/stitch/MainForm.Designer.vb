﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MnFrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MnFrm))
        Me.Lst_SQLScrpt_Nm = New System.Windows.Forms.ListBox()
        Me.But_RunScripts = New System.Windows.Forms.Button()
        Me.Cmbx_CustNm = New System.Windows.Forms.ComboBox()
        Me.Bt_CopyLog = New System.Windows.Forms.Button()
        Me.But_Export2Exl = New System.Windows.Forms.Button()
        Me.dgv_MsmtDta = New System.Windows.Forms.DataGridView()
        Me.But_ErrorChk = New System.Windows.Forms.Button()
        Me.LstV_ErrChk = New System.Windows.Forms.ListView()
        Me.But_UpdateRcds = New System.Windows.Forms.Button()
        Me.but_ExportGrid2Exl = New System.Windows.Forms.Button()
        Me.But_ImprtXL2Grid = New System.Windows.Forms.Button()
        Me.but_ColExpndArrow = New System.Windows.Forms.Button()
        Me.dgv_statusbar = New System.Windows.Forms.Label()
        Me.but_Generate_SQLScrpts = New System.Windows.Forms.Button()
        Me.cmbx_tblNm_insrt = New System.Windows.Forms.ComboBox()
        Me.ckbx_InsertRcds = New System.Windows.Forms.CheckBox()
        Me.ckbx_IncludeAllErrorChkScrpts = New System.Windows.Forms.CheckBox()
        Me.ckbx_crteWthTbl = New System.Windows.Forms.CheckBox()
        Me.but_expndColpse = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pb_mainProcess = New System.Windows.Forms.ProgressBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Grp_NewCust = New System.Windows.Forms.GroupBox()
        Me.cmbx_newCustNm = New System.Windows.Forms.ComboBox()
        Me.grpbx_bscScrpts = New System.Windows.Forms.GroupBox()
        Me.ckbx_DelTbl = New System.Windows.Forms.CheckBox()
        Me.lbl_mainStatsBar = New System.Windows.Forms.Label()
        Me.bgwLongTask = New System.ComponentModel.BackgroundWorker()
        Me.Txt_Log = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.dgv_MsmtDta, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Grp_NewCust.SuspendLayout()
        Me.grpbx_bscScrpts.SuspendLayout()
        Me.SuspendLayout()
        '
        'Lst_SQLScrpt_Nm
        '
        Me.Lst_SQLScrpt_Nm.FormattingEnabled = True
        Me.Lst_SQLScrpt_Nm.Location = New System.Drawing.Point(63, 29)
        Me.Lst_SQLScrpt_Nm.Name = "Lst_SQLScrpt_Nm"
        Me.Lst_SQLScrpt_Nm.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.Lst_SQLScrpt_Nm.Size = New System.Drawing.Size(316, 212)
        Me.Lst_SQLScrpt_Nm.TabIndex = 1
        '
        'But_RunScripts
        '
        Me.But_RunScripts.AutoSize = True
        Me.But_RunScripts.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.But_RunScripts.ForeColor = System.Drawing.Color.White
        Me.But_RunScripts.Location = New System.Drawing.Point(4, 10)
        Me.But_RunScripts.Name = "But_RunScripts"
        Me.But_RunScripts.Size = New System.Drawing.Size(106, 24)
        Me.But_RunScripts.TabIndex = 2
        Me.But_RunScripts.Text = "1.Run Script(s)"
        Me.But_RunScripts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.But_RunScripts.UseVisualStyleBackColor = False
        '
        'Cmbx_CustNm
        '
        Me.Cmbx_CustNm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmbx_CustNm.FormattingEnabled = True
        Me.Cmbx_CustNm.Location = New System.Drawing.Point(385, 31)
        Me.Cmbx_CustNm.Name = "Cmbx_CustNm"
        Me.Cmbx_CustNm.Size = New System.Drawing.Size(123, 21)
        Me.Cmbx_CustNm.TabIndex = 3
        '
        'Bt_CopyLog
        '
        Me.Bt_CopyLog.AutoSize = True
        Me.Bt_CopyLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Bt_CopyLog.ForeColor = System.Drawing.Color.White
        Me.Bt_CopyLog.Location = New System.Drawing.Point(66, 490)
        Me.Bt_CopyLog.Name = "Bt_CopyLog"
        Me.Bt_CopyLog.Size = New System.Drawing.Size(62, 24)
        Me.Bt_CopyLog.TabIndex = 8
        Me.Bt_CopyLog.Text = "Copy Log"
        Me.Bt_CopyLog.UseVisualStyleBackColor = False
        '
        'But_Export2Exl
        '
        Me.But_Export2Exl.AutoSize = True
        Me.But_Export2Exl.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.But_Export2Exl.ForeColor = System.Drawing.Color.White
        Me.But_Export2Exl.Location = New System.Drawing.Point(4, 72)
        Me.But_Export2Exl.Name = "But_Export2Exl"
        Me.But_Export2Exl.Size = New System.Drawing.Size(106, 24)
        Me.But_Export2Exl.TabIndex = 10
        Me.But_Export2Exl.Text = "3.Export to Excel"
        Me.But_Export2Exl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.But_Export2Exl.UseVisualStyleBackColor = False
        '
        'dgv_MsmtDta
        '
        Me.dgv_MsmtDta.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgv_MsmtDta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgv_MsmtDta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_MsmtDta.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.dgv_MsmtDta.Location = New System.Drawing.Point(527, 274)
        Me.dgv_MsmtDta.Name = "dgv_MsmtDta"
        Me.dgv_MsmtDta.Size = New System.Drawing.Size(640, 210)
        Me.dgv_MsmtDta.TabIndex = 12
        '
        'But_ErrorChk
        '
        Me.But_ErrorChk.AutoSize = True
        Me.But_ErrorChk.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.But_ErrorChk.ForeColor = System.Drawing.Color.White
        Me.But_ErrorChk.Location = New System.Drawing.Point(4, 41)
        Me.But_ErrorChk.Name = "But_ErrorChk"
        Me.But_ErrorChk.Size = New System.Drawing.Size(73, 24)
        Me.But_ErrorChk.TabIndex = 15
        Me.But_ErrorChk.Text = "2.Err Check"
        Me.But_ErrorChk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.But_ErrorChk.UseVisualStyleBackColor = False
        '
        'LstV_ErrChk
        '
        Me.LstV_ErrChk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LstV_ErrChk.GridLines = True
        Me.LstV_ErrChk.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.LstV_ErrChk.Location = New System.Drawing.Point(527, 29)
        Me.LstV_ErrChk.MultiSelect = False
        Me.LstV_ErrChk.Name = "LstV_ErrChk"
        Me.LstV_ErrChk.Size = New System.Drawing.Size(641, 205)
        Me.LstV_ErrChk.TabIndex = 19
        Me.LstV_ErrChk.UseCompatibleStateImageBehavior = False
        Me.LstV_ErrChk.View = System.Windows.Forms.View.Details
        '
        'But_UpdateRcds
        '
        Me.But_UpdateRcds.AutoSize = True
        Me.But_UpdateRcds.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.But_UpdateRcds.ForeColor = System.Drawing.Color.White
        Me.But_UpdateRcds.Location = New System.Drawing.Point(1107, 490)
        Me.But_UpdateRcds.Name = "But_UpdateRcds"
        Me.But_UpdateRcds.Size = New System.Drawing.Size(60, 24)
        Me.But_UpdateRcds.TabIndex = 21
        Me.But_UpdateRcds.Text = "Update"
        Me.But_UpdateRcds.UseVisualStyleBackColor = False
        '
        'but_ExportGrid2Exl
        '
        Me.but_ExportGrid2Exl.AutoSize = True
        Me.but_ExportGrid2Exl.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.but_ExportGrid2Exl.ForeColor = System.Drawing.Color.White
        Me.but_ExportGrid2Exl.Location = New System.Drawing.Point(591, 490)
        Me.but_ExportGrid2Exl.Name = "but_ExportGrid2Exl"
        Me.but_ExportGrid2Exl.Size = New System.Drawing.Size(75, 24)
        Me.but_ExportGrid2Exl.TabIndex = 24
        Me.but_ExportGrid2Exl.Text = "Export to XL"
        Me.but_ExportGrid2Exl.UseVisualStyleBackColor = False
        '
        'But_ImprtXL2Grid
        '
        Me.But_ImprtXL2Grid.AutoSize = True
        Me.But_ImprtXL2Grid.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.But_ImprtXL2Grid.ForeColor = System.Drawing.Color.White
        Me.But_ImprtXL2Grid.Location = New System.Drawing.Point(527, 490)
        Me.But_ImprtXL2Grid.Name = "But_ImprtXL2Grid"
        Me.But_ImprtXL2Grid.Size = New System.Drawing.Size(57, 24)
        Me.But_ImprtXL2Grid.TabIndex = 25
        Me.But_ImprtXL2Grid.Text = "Load XL"
        Me.But_ImprtXL2Grid.UseVisualStyleBackColor = False
        '
        'but_ColExpndArrow
        '
        Me.but_ColExpndArrow.AutoSize = True
        Me.but_ColExpndArrow.Location = New System.Drawing.Point(471, 460)
        Me.but_ColExpndArrow.Name = "but_ColExpndArrow"
        Me.but_ColExpndArrow.Size = New System.Drawing.Size(29, 24)
        Me.but_ColExpndArrow.TabIndex = 26
        Me.but_ColExpndArrow.Text = ">>"
        Me.but_ColExpndArrow.UseVisualStyleBackColor = True
        '
        'dgv_statusbar
        '
        Me.dgv_statusbar.BackColor = System.Drawing.Color.Transparent
        Me.dgv_statusbar.Location = New System.Drawing.Point(672, 495)
        Me.dgv_statusbar.Name = "dgv_statusbar"
        Me.dgv_statusbar.Size = New System.Drawing.Size(75, 14)
        Me.dgv_statusbar.TabIndex = 29
        Me.dgv_statusbar.Text = "0"
        Me.dgv_statusbar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'but_Generate_SQLScrpts
        '
        Me.but_Generate_SQLScrpts.AutoSize = True
        Me.but_Generate_SQLScrpts.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.but_Generate_SQLScrpts.ForeColor = System.Drawing.Color.White
        Me.but_Generate_SQLScrpts.Location = New System.Drawing.Point(5, 37)
        Me.but_Generate_SQLScrpts.Name = "but_Generate_SQLScrpts"
        Me.but_Generate_SQLScrpts.Size = New System.Drawing.Size(103, 23)
        Me.but_Generate_SQLScrpts.TabIndex = 31
        Me.but_Generate_SQLScrpts.Text = "Copy Script"
        Me.but_Generate_SQLScrpts.UseVisualStyleBackColor = False
        '
        'cmbx_tblNm_insrt
        '
        Me.cmbx_tblNm_insrt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbx_tblNm_insrt.FormattingEnabled = True
        Me.cmbx_tblNm_insrt.Location = New System.Drawing.Point(753, 493)
        Me.cmbx_tblNm_insrt.Name = "cmbx_tblNm_insrt"
        Me.cmbx_tblNm_insrt.Size = New System.Drawing.Size(276, 21)
        Me.cmbx_tblNm_insrt.TabIndex = 34
        '
        'ckbx_InsertRcds
        '
        Me.ckbx_InsertRcds.AutoSize = True
        Me.ckbx_InsertRcds.BackColor = System.Drawing.Color.Transparent
        Me.ckbx_InsertRcds.Location = New System.Drawing.Point(1035, 495)
        Me.ckbx_InsertRcds.Name = "ckbx_InsertRcds"
        Me.ckbx_InsertRcds.Size = New System.Drawing.Size(66, 17)
        Me.ckbx_InsertRcds.TabIndex = 35
        Me.ckbx_InsertRcds.Text = "INSERT"
        Me.ckbx_InsertRcds.UseVisualStyleBackColor = False
        '
        'ckbx_IncludeAllErrorChkScrpts
        '
        Me.ckbx_IncludeAllErrorChkScrpts.AutoSize = True
        Me.ckbx_IncludeAllErrorChkScrpts.BackColor = System.Drawing.Color.Transparent
        Me.ckbx_IncludeAllErrorChkScrpts.ForeColor = System.Drawing.Color.Black
        Me.ckbx_IncludeAllErrorChkScrpts.Location = New System.Drawing.Point(78, 46)
        Me.ckbx_IncludeAllErrorChkScrpts.Name = "ckbx_IncludeAllErrorChkScrpts"
        Me.ckbx_IncludeAllErrorChkScrpts.Size = New System.Drawing.Size(37, 17)
        Me.ckbx_IncludeAllErrorChkScrpts.TabIndex = 36
        Me.ckbx_IncludeAllErrorChkScrpts.Text = "All"
        Me.ckbx_IncludeAllErrorChkScrpts.UseVisualStyleBackColor = False
        '
        'ckbx_crteWthTbl
        '
        Me.ckbx_crteWthTbl.AutoSize = True
        Me.ckbx_crteWthTbl.BackColor = System.Drawing.Color.Transparent
        Me.ckbx_crteWthTbl.Location = New System.Drawing.Point(8, 66)
        Me.ckbx_crteWthTbl.Name = "ckbx_crteWthTbl"
        Me.ckbx_crteWthTbl.Size = New System.Drawing.Size(93, 17)
        Me.ckbx_crteWthTbl.TabIndex = 37
        Me.ckbx_crteWthTbl.Text = "+Create Table"
        Me.ckbx_crteWthTbl.UseVisualStyleBackColor = False
        '
        'but_expndColpse
        '
        Me.but_expndColpse.AutoSize = True
        Me.but_expndColpse.BackColor = System.Drawing.Color.Transparent
        Me.but_expndColpse.Image = CType(resources.GetObject("but_expndColpse.Image"), System.Drawing.Image)
        Me.but_expndColpse.Location = New System.Drawing.Point(528, 275)
        Me.but_expndColpse.Name = "but_expndColpse"
        Me.but_expndColpse.Size = New System.Drawing.Size(21, 21)
        Me.but_expndColpse.TabIndex = 38
        Me.but_expndColpse.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(527, 254)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(640, 18)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "INSERT/UPDATE RECORDS"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(527, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(641, 17)
        Me.Label3.TabIndex = 40
        Me.Label3.Text = "ERROR SCRIPT STATUS"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pb_mainProcess
        '
        Me.pb_mainProcess.Location = New System.Drawing.Point(63, 461)
        Me.pb_mainProcess.Maximum = 10
        Me.pb_mainProcess.Name = "pb_mainProcess"
        Me.pb_mainProcess.Size = New System.Drawing.Size(100, 23)
        Me.pb_mainProcess.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.pb_mainProcess.TabIndex = 42
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(63, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(316, 17)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "TABLE / SCRIPT NAME (Alt+Click to view Script)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Grp_NewCust
        '
        Me.Grp_NewCust.BackColor = System.Drawing.Color.Transparent
        Me.Grp_NewCust.Controls.Add(Me.cmbx_newCustNm)
        Me.Grp_NewCust.Controls.Add(Me.but_Generate_SQLScrpts)
        Me.Grp_NewCust.Controls.Add(Me.ckbx_crteWthTbl)
        Me.Grp_NewCust.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Grp_NewCust.Location = New System.Drawing.Point(381, 177)
        Me.Grp_NewCust.Name = "Grp_NewCust"
        Me.Grp_NewCust.Size = New System.Drawing.Size(128, 90)
        Me.Grp_NewCust.TabIndex = 45
        Me.Grp_NewCust.TabStop = False
        '
        'cmbx_newCustNm
        '
        Me.cmbx_newCustNm.FormattingEnabled = True
        Me.cmbx_newCustNm.Location = New System.Drawing.Point(5, 10)
        Me.cmbx_newCustNm.Name = "cmbx_newCustNm"
        Me.cmbx_newCustNm.Size = New System.Drawing.Size(103, 21)
        Me.cmbx_newCustNm.TabIndex = 47
        '
        'grpbx_bscScrpts
        '
        Me.grpbx_bscScrpts.BackColor = System.Drawing.Color.Transparent
        Me.grpbx_bscScrpts.Controls.Add(Me.ckbx_DelTbl)
        Me.grpbx_bscScrpts.Controls.Add(Me.But_RunScripts)
        Me.grpbx_bscScrpts.Controls.Add(Me.But_Export2Exl)
        Me.grpbx_bscScrpts.Controls.Add(Me.ckbx_IncludeAllErrorChkScrpts)
        Me.grpbx_bscScrpts.Controls.Add(Me.But_ErrorChk)
        Me.grpbx_bscScrpts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpbx_bscScrpts.Location = New System.Drawing.Point(381, 50)
        Me.grpbx_bscScrpts.Name = "grpbx_bscScrpts"
        Me.grpbx_bscScrpts.Size = New System.Drawing.Size(127, 124)
        Me.grpbx_bscScrpts.TabIndex = 46
        Me.grpbx_bscScrpts.TabStop = False
        '
        'ckbx_DelTbl
        '
        Me.ckbx_DelTbl.AutoSize = True
        Me.ckbx_DelTbl.BackColor = System.Drawing.Color.Transparent
        Me.ckbx_DelTbl.Location = New System.Drawing.Point(7, 102)
        Me.ckbx_DelTbl.Name = "ckbx_DelTbl"
        Me.ckbx_DelTbl.Size = New System.Drawing.Size(87, 17)
        Me.ckbx_DelTbl.TabIndex = 40
        Me.ckbx_DelTbl.Text = "Delete Table"
        Me.ckbx_DelTbl.UseVisualStyleBackColor = False
        '
        'lbl_mainStatsBar
        '
        Me.lbl_mainStatsBar.BackColor = System.Drawing.Color.Transparent
        Me.lbl_mainStatsBar.Location = New System.Drawing.Point(169, 461)
        Me.lbl_mainStatsBar.Name = "lbl_mainStatsBar"
        Me.lbl_mainStatsBar.Size = New System.Drawing.Size(296, 23)
        Me.lbl_mainStatsBar.TabIndex = 47
        Me.lbl_mainStatsBar.Text = "Status Bar"
        Me.lbl_mainStatsBar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'bgwLongTask
        '
        Me.bgwLongTask.WorkerReportsProgress = True
        Me.bgwLongTask.WorkerSupportsCancellation = True
        '
        'Txt_Log
        '
        Me.Txt_Log.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Log.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_Log.Location = New System.Drawing.Point(63, 253)
        Me.Txt_Log.Name = "Txt_Log"
        Me.Txt_Log.Size = New System.Drawing.Size(441, 201)
        Me.Txt_Log.TabIndex = 48
        Me.Txt_Log.Text = ""
        '
        'Button1
        '
        Me.Button1.AutoSize = True
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(12, 400)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(30, 24)
        Me.Button1.TabIndex = 41
        Me.Button1.Text = "(' ')"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.AutoSize = True
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(119, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(12, 430)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(30, 24)
        Me.Button2.TabIndex = 49
        Me.Button2.Text = "( )"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'MnFrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1186, 519)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.but_expndColpse)
        Me.Controls.Add(Me.dgv_MsmtDta)
        Me.Controls.Add(Me.Cmbx_CustNm)
        Me.Controls.Add(Me.grpbx_bscScrpts)
        Me.Controls.Add(Me.Grp_NewCust)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pb_mainProcess)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ckbx_InsertRcds)
        Me.Controls.Add(Me.cmbx_tblNm_insrt)
        Me.Controls.Add(Me.dgv_statusbar)
        Me.Controls.Add(Me.but_ColExpndArrow)
        Me.Controls.Add(Me.But_ImprtXL2Grid)
        Me.Controls.Add(Me.but_ExportGrid2Exl)
        Me.Controls.Add(Me.But_UpdateRcds)
        Me.Controls.Add(Me.LstV_ErrChk)
        Me.Controls.Add(Me.Bt_CopyLog)
        Me.Controls.Add(Me.Lst_SQLScrpt_Nm)
        Me.Controls.Add(Me.Txt_Log)
        Me.Controls.Add(Me.lbl_mainStatsBar)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MnFrm"
        Me.Text = "Stitch"
        CType(Me.dgv_MsmtDta, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Grp_NewCust.ResumeLayout(False)
        Me.Grp_NewCust.PerformLayout()
        Me.grpbx_bscScrpts.ResumeLayout(False)
        Me.grpbx_bscScrpts.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Lst_SQLScrpt_Nm As System.Windows.Forms.ListBox
    Friend WithEvents But_RunScripts As System.Windows.Forms.Button
    Friend WithEvents Cmbx_CustNm As System.Windows.Forms.ComboBox
    Friend WithEvents Bt_CopyLog As System.Windows.Forms.Button
    Friend WithEvents But_Export2Exl As System.Windows.Forms.Button
    Friend WithEvents dgv_MsmtDta As System.Windows.Forms.DataGridView
    Friend WithEvents But_ErrorChk As System.Windows.Forms.Button
    Friend WithEvents LstV_ErrChk As System.Windows.Forms.ListView
    Friend WithEvents But_UpdateRcds As System.Windows.Forms.Button
    Friend WithEvents but_ExportGrid2Exl As System.Windows.Forms.Button
    Friend WithEvents But_ImprtXL2Grid As System.Windows.Forms.Button
    Friend WithEvents but_ColExpndArrow As System.Windows.Forms.Button
    Friend WithEvents dgv_statusbar As System.Windows.Forms.Label
    Friend WithEvents but_Generate_SQLScrpts As System.Windows.Forms.Button
    Friend WithEvents cmbx_tblNm_insrt As System.Windows.Forms.ComboBox
    Friend WithEvents ckbx_InsertRcds As System.Windows.Forms.CheckBox
    Friend WithEvents ckbx_IncludeAllErrorChkScrpts As System.Windows.Forms.CheckBox
    Friend WithEvents ckbx_crteWthTbl As System.Windows.Forms.CheckBox
    Friend WithEvents but_expndColpse As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents pb_mainProcess As System.Windows.Forms.ProgressBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Grp_NewCust As System.Windows.Forms.GroupBox
    Friend WithEvents grpbx_bscScrpts As System.Windows.Forms.GroupBox
    Friend WithEvents ckbx_DelTbl As System.Windows.Forms.CheckBox
    Friend WithEvents cmbx_newCustNm As System.Windows.Forms.ComboBox
    Friend WithEvents lbl_mainStatsBar As System.Windows.Forms.Label
    Private WithEvents bgwLongTask As System.ComponentModel.BackgroundWorker
    Friend WithEvents Txt_Log As System.Windows.Forms.RichTextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
