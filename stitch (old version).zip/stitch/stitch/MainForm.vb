﻿Imports System.Data.SqlClient
Imports Microsoft.WindowsAPICodePack.Taskbar
Imports System.IO
Imports System.Text.RegularExpressions

Public Module GlobalVariables
    Public RootPath As String
    Public CustPath As String
    Public XMLPath As String
    Public ErrChkScrptPath As String
    Public ExlExprtPath As String
    Public DeleteRcdsSQLQry As String
    Public CustPathCustName As String
    Public ServerNm As String
    Public DBNm As String
    Public TotalScrpts As Integer
    Public UpdtLogFlg As Boolean
    Public UpDtLogMsg1 As Boolean
    Public UpDtLogMsg2 As String
    Public Length As Integer

    '******************************************************************************************************
    Public ImgPath As String = ""
    '******************************************************************************************************
End Module
Public Class MnFrm
    Private Sub UserForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load


        'Dim path As String = AppDomain.CurrentDomain.BaseDirectory
        Dim prjPath As String = Directory.GetCurrentDirectory

        ImgPath = prjPath.Replace("\bin\Debug", "\images")

        '**********************************************************************************
        RootPath = "C:\Users\" & Environ("UserName") & "\Desktop\Stitch\"
        '**********************************************************************************
        CustPath = (RootPath & "SQL_Scripts\Customer\")

        ExlExprtPath = (RootPath & "Excel_Export\")
        ErrChkScrptPath = (RootPath & "SQL_Scripts\ErrorCheck\")
        XMLPath = (RootPath & "XML\")

        'Checking and creating Folders
        CheckFolder(RootPath)
        CheckFolder(RootPath & "SQL_Scripts\")
        CheckFolder(CustPath)
        CheckFolder(ErrChkScrptPath)
        CheckFolder(XMLPath)
        CheckFolder(ExlExprtPath)

        '**********************************************************************************
        ServerNm = "DESKTOP-I82B0EV"
        DBNm = "TEST"
        '**********************************************************************************

        MaximizeBox = False

        Retrive_Cust_FolderNames(CustPath)
        If Me.Cmbx_CustNm.Items.Count > 0 Then Me.Cmbx_CustNm.SelectedIndex = 0

        Me.but_ColExpndArrow.Text = "<<"
        but_ColExpndArrow_Click(sender, New System.EventArgs())

        Dim toolTip1 As New ToolTip()
        toolTip1.AutoPopDelay = 5000
        toolTip1.InitialDelay = 1000
        toolTip1.ReshowDelay = 500
        ' Force the ToolTip text to be displayed whether or not the form is active.
        toolTip1.ShowAlways = True
        toolTip1.SetToolTip(Me.but_Generate_SQLScrpts, "use this option to create new SQL Scripts")
        toolTip1.SetToolTip(Me.cmbx_newCustNm, "fill new customer name")
        Me.cmbx_tblNm_insrt.Enabled = False
        Dim bm As New Bitmap(ImgPath & "\expand.png")
        Me.but_expndColpse.Image = bm

    End Sub
    Private Sub Cmbx_CustNm_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles Cmbx_CustNm.SelectedIndexChanged
        If Me.Cmbx_CustNm.Text = (Me.Cmbx_CustNm.Items((Me.Cmbx_CustNm.Items.Count - 1))) Then
            Me.cmbx_newCustNm.Text = "NewCustName?"
            Grp_NewCust.Top = 50
            Grp_NewCust.Visible = True
            grpbx_bscScrpts.Visible = False
            Exit Sub
        ElseIf Me.Cmbx_CustNm.Text = "Refresh" Then
            Retrive_Cust_FolderNames(CustPath)
            Exit Sub
        Else
            Grp_NewCust.Visible = False
            grpbx_bscScrpts.Visible = True
        End If
        Me.Lst_SQLScrpt_Nm.Items.Clear()
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        CustPathCustName = CustPath & Me.Cmbx_CustNm.Text & "\"
        BasicFunc.Retrive_SQL_Scripts(CustPath & Me.Cmbx_CustNm.Text)
        Me.pb_mainProcess.Value = Me.pb_mainProcess.Maximum
        UpdateLog(True, "<<END")
    End Sub
    Private Sub But_RunScripts_Click(sender As System.Object, e As System.EventArgs) Handles But_RunScripts.Click
        If Control.ModifierKeys = Keys.Alt Then
            Try
                Process.Start(CustPathCustName)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If

        If SelectionCheck(False) = False Then Exit Sub
        Me.but_ColExpndArrow.Text = "<<"
        but_ColExpndArrow_Click(sender, New System.EventArgs())

        If Me.But_RunScripts.Text = "Cancelling..." Then Exit Sub

        UpdateLog(True, "START>>")
        TotalScrpts = Me.Lst_SQLScrpt_Nm.SelectedItems.Count()
        Me.pb_mainProcess.Value = 0
        Me.pb_mainProcess.Maximum = 100
        TaskbarManager.Instance.SetProgressValue(0, 100)

        Me.Lst_SQLScrpt_Nm.Enabled = False
        Me.Lst_SQLScrpt_Nm.Enabled = False
        Me.But_ErrorChk.Enabled = False
        Me.But_Export2Exl.Enabled = False
        Me.ckbx_DelTbl.Enabled = False
        Me.but_ColExpndArrow.Enabled = False

        If Me.But_RunScripts.Text = "Cancelling..." Then Exit Sub
        If Me.But_RunScripts.Text = "Cancel" Then
            bgwLongTask.CancelAsync()
            Me.But_RunScripts.Text = "Cancelling..."
        ElseIf Me.But_RunScripts.Text = "1.Run Script(s)" Or Me.But_RunScripts.Text = "Delete Table(s)" Then
            bgwLongTask.RunWorkerAsync()
            If Me.ckbx_DelTbl.Checked = False Then Me.But_RunScripts.Text = "Cancel"
        ElseIf bgwLongTask.IsBusy = True Then
            MsgBox("there is other process running...", MsgBoxStyle.Information, "Server Busy...")
            UpdateLog(True, "<<END")
        End If

        'BasicFunc.Run_SQL_Scrpt()
        ' UpdateLog(True, "<<END")
    End Sub
    Private Sub Bt_CopyLog_Click(sender As System.Object, e As System.EventArgs) Handles Bt_CopyLog.Click

        If Control.ModifierKeys = Keys.Alt Then
            Try
                Dim flePath As String = XMLPath & "\Log_" & Format(Now(), "mmddyy_hhmmss") & ".txt"
                Dim NewFle = System.IO.File.CreateText(flePath)
                NewFle.WriteLine(Me.Txt_Log.Text)
                NewFle.Close()
                Process.Start("notepad.exe", flePath)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If
        Me.pb_mainProcess.Value = 0
        If Me.Txt_Log.Text <> "" Then Clipboard.SetText(Me.Txt_Log.Text)
    End Sub
    Private Sub But_Export2Exl_Click(sender As System.Object, e As System.EventArgs) Handles But_Export2Exl.Click

        If Control.ModifierKeys = Keys.Alt Then
            Try
                Process.Start(ExlExprtPath)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If

        If SelectionCheck(False) = False Then Exit Sub
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        BasicFunc.Export2Exl()
        UpdateLog(True, "<<END")
        'Process.Start(RootPath & "Excel_Export\")
    End Sub
    Private Sub But_ErrorChk_Click(sender As System.Object, e As System.EventArgs) Handles But_ErrorChk.Click

        If Control.ModifierKeys = Keys.Alt Then
            Try
                Process.Start(RootPath & "SQL_Scripts\ErrorCheck")
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If

        If Me.ckbx_IncludeAllErrorChkScrpts.Checked = False Then
            If SelectionCheck(True) = False Then Exit Sub
        End If

        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        If BasicFunc.Retrive_ErrorChk_Scripts(RootPath & "SQL_Scripts\ErrorCheck") = 0 Then
            BasicFunc.UpdateLog(True, "ERROR...No related Scripts Found")
        Else
            BasicFunc.Run_ErrorChk_Scripts()
            Me.but_ColExpndArrow.Text = ">>"
            but_ColExpndArrow_Click(sender, New System.EventArgs())
        End If
        UpdateLog(True, "<<END")

    End Sub
    Private Sub But_UpdateRcds_Click(sender As System.Object, e As System.EventArgs) Handles But_UpdateRcds.Click
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        'Me.dgv_MsmtDta.RowCount = 1 Or Me.LstV_ErrChk.Items.Count = -1 Or
        If Me.cmbx_tblNm_insrt.Text = "" Then '
            UpdateLog(True, "ERROR...no source table / error script found.")
        Else
            BasicFunc.Update_DtaVw_Rcds()
        End If
        UpdateLog(True, "<<END")
    End Sub
    Private Sub Lst_SQLScrpt_Nm_DoubleClick(sender As Object, e As System.EventArgs) Handles Lst_SQLScrpt_Nm.DoubleClick
        If Control.ModifierKeys = Keys.Alt Then
            Process.Start(CustPathCustName & Me.Lst_SQLScrpt_Nm.Text)
            Exit Sub
        End If

        Me.but_ColExpndArrow.Text = ">>"
        but_ColExpndArrow_Click(sender, New System.EventArgs())
        ckbx_InsertRcds.Checked = True

        Dim flNm As String = Regex.Replace(Me.Lst_SQLScrpt_Nm.Text, ".SQL", "", RegexOptions.IgnoreCase)
        flNm = Microsoft.VisualBasic.Right(flNm, Len(flNm) - InStrRev(flNm, "."))
        Me.cmbx_tblNm_insrt.Text = flNm
        ' Me.ckbx_InsertRcds.Checked = True

    End Sub
    Private Sub but_ExportGrid2Exl_Click(sender As System.Object, e As System.EventArgs) Handles but_ExportGrid2Exl.Click
        If Control.ModifierKeys = Keys.Alt Then
            Try
                Process.Start(ExlExprtPath)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
            End Try
            Exit Sub
        End If
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        Export_Grid_2_Exl()
        UpdateLog(True, "<<END")
    End Sub
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles But_ImprtXL2Grid.Click
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        Load_XL2Grid()
        UpdateLog(True, "<<END")
        Refresh_Grid()
    End Sub
    Private Sub LstV_ErrChk_MouseClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles LstV_ErrChk.MouseClick
        If Control.ModifierKeys = Keys.Alt Then
            Process.Start(ErrChkScrptPath & Me.LstV_ErrChk.SelectedItems(0).SubItems(0).Text)
            Exit Sub
        End If

        LstV_ErrChk.BeginUpdate()
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        Me.ckbx_InsertRcds.Checked = False
        If (Me.LstV_ErrChk.SelectedItems(0).SubItems(2).Text) = "ERROR" Then
            Me.dgv_MsmtDta.DataSource = 0
            UpdateLog(True, "ERROR...error with script ,please check and re-run")
        ElseIf (Me.LstV_ErrChk.SelectedItems(0).SubItems(1).Text) = 0 Then
            Me.dgv_MsmtDta.DataSource = 0
            UpdateLog(True, "NO RECORDS")
        Else
            'Getting source table name
            Me.cmbx_tblNm_insrt.Text = Me.LstV_ErrChk.SelectedItems(0).SubItems(3).Text

            Me.LstV_ErrChk.SelectedItems(0).SubItems(1).Text = Load_ErrorChk_Scripts2DataGrid(
                Me.LstV_ErrChk.SelectedItems(0).SubItems(0).Text)
            If Me.LstV_ErrChk.SelectedItems(0).SubItems(1).Text = 0 Then
                Me.LstV_ErrChk.SelectedItems(0).SubItems(2).Text = "PASS"
                Me.LstV_ErrChk.SelectedItems(0).SubItems(2).BackColor = Color.LimeGreen
            End If
        End If
        UpdateLog(True, "<<END")
        Refresh_Grid()
        LstV_ErrChk.EndUpdate()
    End Sub
    Public Sub dgv_MsmtDta_SelectionChanged(sender As Object, e As System.EventArgs) Handles dgv_MsmtDta.SelectionChanged
        Call Refresh_Grid()
    End Sub
    Private Sub Generate_SQLScrpts_Click(sender As System.Object, e As System.EventArgs) Handles but_Generate_SQLScrpts.Click
        If Control.ModifierKeys = Keys.Alt Then
            Try
                Process.Start(CustPath & Me.cmbx_newCustNm.Text)
            Catch ex As Exception
                UpdateLog(True, "ERROR..." & Err.Description)
                Exit Sub
            End Try
            Exit Sub
        End If
        If Me.cmbx_newCustNm.Text = "NewCustName?" Then
            MsgBox("Please choose/enter Customer Name", MsgBoxStyle.Critical)
            Exit Sub
        End If
        If ckbx_crteWthTbl.Checked = False Then
            If SelectionCheck(False) = False Then Exit Sub
        Else
            If SelectionCheck(True) = False Then Exit Sub
        End If
        UpdateLog(True, "START>>")
        Me.pb_mainProcess.Value = 0
        Create_ScrptTbl(Me.ckbx_crteWthTbl.Checked, CustPath & Me.cmbx_newCustNm.Text)
        UpdateLog(True, "<<END")
        'Dim LastScript() As String = Split(Me.Txt_Log.Text, "START>>")
        'If InStr((LastScript(UBound(LastScript))), "ERROR...") = 0 Then
        '    Retrive_Cust_FolderNames(CustPath)
        '    Me.Cmbx_CustNm.Text = Me.cmbx_newCustNm.Text
        'End If
    End Sub
    Private Sub ckbx_InsertRcds_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles ckbx_InsertRcds.CheckedChanged
        If Me.ckbx_InsertRcds.Checked = True Then
            Me.But_UpdateRcds.Text = "INSERT"
            Me.cmbx_tblNm_insrt.Enabled = True
            Me.cmbx_tblNm_insrt.DropDownStyle = ComboBoxStyle.DropDown
        Else
            Me.But_UpdateRcds.Text = "UPDATE"
            Me.cmbx_tblNm_insrt.Enabled = False
            Me.cmbx_tblNm_insrt.DropDownStyle = ComboBoxStyle.DropDownList
        End If
    End Sub
    Private Sub ckbx_crteWthTbl_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles ckbx_crteWthTbl.CheckedChanged
        If ckbx_crteWthTbl.Checked = True Then
            Me.but_Generate_SQLScrpts.Text = "Create Tbl+Script"
        Else
            Me.but_Generate_SQLScrpts.Text = "COPY Script"
        End If
    End Sub
    Private Sub but_expndColpse_Click(sender As System.Object, e As System.EventArgs) Handles but_expndColpse.Click

        If Me.dgv_MsmtDta.Width = 1163 Then
            Me.dgv_MsmtDta.Left = 527
            Me.dgv_MsmtDta.Top = 274
            Me.dgv_MsmtDta.Height = 210
            Me.dgv_MsmtDta.Width = 640
            Me.but_expndColpse.Left = 527
            Me.but_expndColpse.Top = 275
            Dim bm As New Bitmap("C:\Users\dlohia\Documents\Visual Studio 2010\Projects\stitch\stitch\bin\expand.png")
            Me.but_expndColpse.Image = bm
            Bt_CopyLog.Visible = True
        Else
            Me.dgv_MsmtDta.Left = 6
            Me.dgv_MsmtDta.Top = 8
            Me.dgv_MsmtDta.Height = 476
            Me.dgv_MsmtDta.Width = 1163
            Me.but_expndColpse.Left = 6
            Me.but_expndColpse.Top = 8
            ' Load the picture into a Bitmap.
            Dim bm As New Bitmap("C:\Users\dlohia\Documents\Visual Studio 2010\Projects\stitch\stitch\bin\collapse.png")
            Me.but_expndColpse.Image = bm
            Me.Bt_CopyLog.Visible = False
        End If

    End Sub

    Private Sub but_ColExpndArrow_Click(sender As System.Object, e As System.EventArgs) Handles but_ColExpndArrow.Click
        If Me.but_ColExpndArrow.Text = "<<" Then
            Me.Width = 518
            Me.but_ColExpndArrow.Text = ">>"
        Else
            Me.Width = 1185
            Me.but_ColExpndArrow.Text = "<<"
        End If
        Me.CenterToScreen()
    End Sub

    Private Sub ckbx_DelTbl_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles ckbx_DelTbl.CheckedChanged
        If Me.ckbx_DelTbl.Checked = True Then
            Me.But_RunScripts.BackColor = Color.Red
            Me.But_RunScripts.Text = "Delete Table(s)"
        Else
            Me.But_RunScripts.BackColor = Color.FromArgb(232, 119, 34)
            If Me.ckbx_DelTbl.Checked = False Then Me.But_RunScripts.Text = "1.Run Script(s)"
        End If
    End Sub

    Private Sub bgwLongTask_ProgressChanged(sender As System.Object, e As System.ComponentModel.ProgressChangedEventArgs) Handles bgwLongTask.ProgressChanged
        If UpdtLogFlg = False Then
            Me.pb_mainProcess.Value = e.ProgressPercentage
            TaskbarManager.Instance.SetProgressValue(e.ProgressPercentage, 100)
            UpdateLog(UpDtLogMsg1, UpDtLogMsg2)
        Else
            UpdateLog(UpDtLogMsg1, UpDtLogMsg2)
        End If
    End Sub

    Private Sub bgwLongTask_RunWorkerCompleted(sender As System.Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles bgwLongTask.RunWorkerCompleted
        If (e.Cancelled) = True Then UpdateLog(True, "CANCELLED by User")
        Me.Lst_SQLScrpt_Nm.Enabled = True
        Me.But_ErrorChk.Enabled = True
        Me.But_Export2Exl.Enabled = True
        Me.ckbx_DelTbl.Enabled = True
        Me.but_ColExpndArrow.Enabled = True
        If Me.ckbx_DelTbl.Checked = False Then Me.But_RunScripts.Text = "1.Run Script(s)"
        UpdateLog(True, "<<END")
    End Sub
 
    Private Sub Run_SQL_Scrpt(sender As System.Object, e As System.ComponentModel.DoWorkEventArgs) Handles bgwLongTask.DoWork
        Dim NmbrOfScrpt As Integer
        Dim watch As New Stopwatch()
        Dim FlPath As String
        Dim FlNm As String
        Dim Script
        Dim ScrptBtch As String()
        Dim transaction As SqlTransaction
        Dim TblNm As String
        Dim TblExists As Integer
        Dim UpdMsg As String
        Dim connectionString As String = "Data Source=" & ServerNm & ";Initial Catalog=" & DBNm & ";Integrated Security=SSPI"
        Dim connection As SqlConnection = New SqlConnection(connectionString)
        Dim cmd As SqlCommand = New SqlCommand()
        cmd.Connection = connection
        If Not connection Is Nothing Then connection.Close()
        connection.Open()

        If Me.ckbx_DelTbl.Checked = False Then cmd.CommandTimeout = 3600
        'Me.pb_mainProcess.Maximum = Me.Lst_SQLScrpt_Nm.SelectedItems.Count()

        For Each itm In Me.Lst_SQLScrpt_Nm.SelectedItems
            UpdtLogFlg = True
            FlNm = itm.name
            FlPath = CustPathCustName & FlNm
            Try
                If Me.ckbx_DelTbl.Checked = True Then
                    TblNm = FlNm
                    TblNm = Regex.Replace(TblNm, ".sql", "", RegexOptions.IgnoreCase)
                    TblNm = Microsoft.VisualBasic.Right(TblNm, Len(TblNm) - InStrRev(TblNm, "."))
                    TblNm = DBNm & ".dbo." & TblNm
                    Script = "SELECT COUNT(*) FROM sys.objects " & _
                           "WHERE object_id = OBJECT_ID('" & TblNm & "',N'U') "
                    cmd.CommandText = Script
                    Threading.Thread.Sleep(1000)
                    UpDtLogMsg2 = "CHECKING-" & TblNm  'in case query error we should should know where are we !!
                    TblExists = cmd.ExecuteScalar()
                    If TblExists = 0 Then
                        UpdMsg = "TABLE ALREADY DELETED-"
                    Else
                        Script = "IF OBJECT_ID ('" & TblNm & "',N'U') IS NOT NULL DROP TABLE " & TblNm
                        cmd.CommandText = Script
                        cmd.ExecuteNonQuery()
                        UpdMsg = "DELETED TABLE-"
                    End If
                    Threading.Thread.Sleep(1000)
                    UpDtLogMsg1 = True
                    UpDtLogMsg2 = UpdMsg & TblNm
                    UpDtLogMsg2 = Regex.Replace(UpDtLogMsg2, DBNm & ".dbo.", "", RegexOptions.IgnoreCase)
                    Threading.Thread.Sleep(1000)
                    GoTo NxtScrpt
                Else
                    Script = System.IO.File.ReadAllText(FlPath)
                    If InStr(Script, ";") > 0 Then
                        Threading.Thread.Sleep(1000)
                        UpDtLogMsg1 = True
                        UpDtLogMsg2 = "ERROR...Please remove semi-colon (;) from the Script """ & FlPath & """" & "-SKIPPED"
                        GoTo NxtScrpt
                    End If
                    Script = Regex.Replace(Script, vbCr & vbLf & "GO" & vbCr & vbLf, ";", RegexOptions.IgnoreCase)
                    Threading.Thread.Sleep(1000)
                    UpdtLogFlg = True
                    UpDtLogMsg1 = True
                    UpDtLogMsg2 = "RUNNING... " & FlNm
                    bgwLongTask.ReportProgress(NmbrOfScrpt)
                End If

                ScrptBtch = Split(Script, ";")
                watch.Start()

                ' Execute as a transaction, roll back if it fails
                transaction = connection.BeginTransaction()
                cmd.Transaction = transaction
                For i = 0 To ScrptBtch.Length - 1
                    If ScrptBtch(i).Length > 0 Then
                        Try
                            If (bgwLongTask.CancellationPending) Then
                                ' Indicate that the task was canceled.
                                connection.Close()
                                cmd.Dispose()
                                e.Cancel = True
                                Exit Sub
                            End If
                            cmd.CommandText = ScrptBtch(i)
                            cmd.ExecuteNonQuery()
                        Catch ex As Exception
                            UpDtLogMsg1 = True
                            UpDtLogMsg2 = "ERROR..." & Err.Description & FlPath & "..ROLLED BACK" & vbNewLine & ScrptBtch(i)
                            transaction.Rollback()
                            GoTo NxtScrpt
                        End Try
                    End If
                Next
                transaction.Commit()
                watch.Stop()

                UpDtLogMsg1 = False
                If watch.Elapsed.TotalSeconds.ToString > 120 Then
                    UpDtLogMsg2 = "...DONE- " & watch.Elapsed.TotalMinutes.ToString("0.00") & "min"
                Else
                    UpDtLogMsg2 = "...DONE- " & watch.Elapsed.TotalSeconds.ToString("0.00") & "sec"
                End If
            Catch ex As Exception
                UpDtLogMsg1 = True
                UpDtLogMsg2 = "ERROR..." & Err.Description
                bgwLongTask.ReportProgress(0)
            End Try
NxtScrpt:
            NmbrOfScrpt = NmbrOfScrpt + 1
            UpdtLogFlg = False
            bgwLongTask.ReportProgress((100 / TotalScrpts) * NmbrOfScrpt)
        Next
        connection.Close()
        cmd.Dispose()
    End Sub


    Private Sub Button1_Click_1(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim returnHtmlText As String = Nothing
        Dim StrOutpt
        Dim strList As New List(Of String)
        Using reader As New StringReader(Clipboard.GetText())
            While reader.Peek() <> -1
                If StrOutpt = "" Then
                    StrOutpt = "'" & Trim(reader.ReadLine()) & "'"
                Else
                    StrOutpt = StrOutpt & ", " & vbNewLine & "'" & Trim(reader.ReadLine()) & "'"
                End If

            End While
        End Using
        Clipboard.SetText("(" & StrOutpt & ")", TextDataFormat.Text)

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim returnHtmlText As String = Nothing
        Dim StrOutpt
        Dim strList As New List(Of String)
        Using reader As New StringReader(Clipboard.GetText())
            While reader.Peek() <> -1
                If StrOutpt = "" Then
                    StrOutpt = "'" & Trim(reader.ReadLine()) & "'"
                Else
                    StrOutpt = StrOutpt & ", " & vbNewLine & "'" & Trim(reader.ReadLine()) & "'"
                End If

            End While
        End Using
        Clipboard.SetText("(" & StrOutpt & ")", TextDataFormat.Text)
    End Sub
End Class

